package com.example.tasktracker;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.animation.AlphaAnimation;
import android.view.animation.TranslateAnimation;
import android.net.Uri;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    static final String PREF="task_tracker_v4";
    static final String OLD_PREF_V3="task_tracker_v3";
    static final String OLD_PREF_V2="v2";
    static final String OLD_PREF_V1="tasks";
    static final int PURPLE=Color.rgb(79,70,229);
    static final int GREEN=Color.rgb(22,163,74), RED=Color.rgb(220,38,38), GRAY=Color.rgb(156,163,175), BG=Color.rgb(248,248,250);
    LinearLayout content; TextView title,summary;
    ArrayList<Task> tasks=new ArrayList<>(); SharedPreferences sp;
    Calendar monthCursor=Calendar.getInstance();
    final SimpleDateFormat dayKey=new SimpleDateFormat("yyyy-MM-dd",Locale.US);
    final SimpleDateFormat niceDate=new SimpleDateFormat("EEE, dd MMM yyyy",Locale.US);

    static class Task {
        String id,name,category,priority,repeat,note,reminder; boolean fav;
        HashMap<String,Integer> history=new HashMap<>();
        Task(String id,String name,String category,String priority,String repeat,String note){this(id,name,category,priority,repeat,note,"");}
        Task(String id,String name,String category,String priority,String repeat,String note,String reminder){this.id=id;this.name=name;this.category=category;this.priority=priority;this.repeat=repeat;this.note=note;this.reminder=reminder==null?"":reminder;}
        int status(String d){Integer v=history.get(d);return v==null?0:v;}
        void setStatus(String d,int s){if(s==0)history.remove(d);else history.put(d,s);}
    }

    public void onCreate(Bundle b){super.onCreate(b);sp=getSharedPreferences(PREF,MODE_PRIVATE);load();createNotificationChannel();if(Build.VERSION.SDK_INT>=33)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},500);buildShell();showMonth();scheduleAllReminders();}
    String todayKey(){return dayKey.format(new Date());}
    TextView text(String s,float size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.rgb(28,28,38));t.setPadding(10,8,10,8);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(14);b.setTextColor(Color.rgb(30,30,35));b.setAllCaps(false);b.setPadding(8,0,8,0);styleButton(b);return b;}

    void buildShell(){
        getWindow().setStatusBarColor(Color.rgb(248,248,250));
        getWindow().setNavigationBarColor(Color.rgb(248,248,250));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setClipChildren(false);root.setClipToPadding(false);root.setPadding(14,0,14,0);
        title=text("Task Tracker V17",28);title.setTypeface(null,1);title.setGravity(Gravity.CENTER);title.setIncludeFontPadding(true);title.setPadding(4,4,4,4);
        LinearLayout.LayoutParams titleLp=new LinearLayout.LayoutParams(-1,78);titleLp.setMargins(0,4,0,8);root.addView(title,titleLp);
        summary=text("",15);summary.setGravity(Gravity.CENTER_VERTICAL);summary.setPadding(14,8,14,8);summary.setGravity(Gravity.CENTER_VERTICAL);summary.setSingleLine(true);summary.setEllipsize(android.text.TextUtils.TruncateAt.END);summary.setBackground(round(Color.rgb(244,244,248),18));root.addView(summary,new LinearLayout.LayoutParams(-1,52));
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(0,18,0,40);
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.setClipToPadding(false);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this);nav.setPadding(4,5,4,5);nav.setBackground(round(Color.rgb(242,242,246),20));
        String[] ns={"Today","Month","Stats","Tasks","More"};
        for(String n:ns){Button b=btn(n);b.setTextSize(14);b.setOnClickListener(v->{if(n.equals("Today"))showDay(todayKey(),"Today");else if(n.equals("Month"))showMonth();else if(n.equals("Stats"))showStats();else if(n.equals("Tasks"))showTasks();else showMore();});nav.addView(b,new LinearLayout.LayoutParams(0,58,1));}
        root.addView(nav,new LinearLayout.LayoutParams(-1,68));setContentView(root);
        if(Build.VERSION.SDK_INT>=30){root.setOnApplyWindowInsetsListener((v,insets)->{android.graphics.Insets bars=insets.getInsets(android.view.WindowInsets.Type.systemBars());v.setPadding(14,bars.top+8,14,bars.bottom+12);return insets;});root.requestApplyInsets();}
    }
    GradientDrawable round(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);return g;}
    void styleButton(Button b){b.setBackground(round(Color.rgb(236,237,239),18));b.setMinHeight(54);b.setStateListAnimator(null);b.setElevation(2);}
    void styleStatusButton(Button b,int status){int c=status==1?Color.rgb(220,252,231):status==2?Color.rgb(254,226,226):Color.rgb(243,244,246);b.setBackground(round(c,18));b.setTextColor(status==1?Color.rgb(21,128,61):status==2?Color.rgb(185,28,28):Color.rgb(55,65,81));b.setTypeface(null,Typeface.BOLD);}
    HorizontalScrollView graphScroll(View v,int width,int height){
        HorizontalScrollView h=new HorizontalScrollView(this);h.setFillViewport(false);h.setHorizontalScrollBarEnabled(true);h.setOverScrollMode(View.OVER_SCROLL_ALWAYS);
        FrameLayout frame=new FrameLayout(this);frame.setMinimumWidth(width);frame.setMinimumHeight(height);frame.addView(v,new FrameLayout.LayoutParams(width,height));
        h.addView(frame,new HorizontalScrollView.LayoutParams(width,height));
        return h;
    }
    void clear(String h){title.setText(h);title.setTextSize(28);title.setIncludeFontPadding(true);content.removeAllViews();content.setAlpha(0f);content.setTranslationY(18f);content.animate().alpha(1f).translationY(0f).setDuration(260).start();}
    String keyFor(int y,int m,int d){Calendar c=new GregorianCalendar(y,m,d);return dayKey.format(c.getTime());}
    String nice(String k){try{return niceDate.format(dayKey.parse(k));}catch(Exception e){return k;}}
    boolean expected(Task t,String k){if(t.repeat.equals("Daily")||t.repeat.equals("Monthly"))return true;if(t.repeat.equals("Weekly"))return true;return t.history.containsKey(k)||k.equals(todayKey());}
    boolean isFuture(String k){return k.compareTo(todayKey())>0;}
    int total(String k){return isFuture(k)?0:tasks.size();}
    int yes(String k){int n=0;for(Task t:tasks)if(t.status(k)==1)n++;return n;}
    int no(String k){int n=0;for(Task t:tasks)if(t.status(k)==2)n++;return n;}
    int pct(String k){int n=total(k);return n==0?0:Math.round(yes(k)*100f/n);}
    void updateSummary(String k){int n=total(k),y=yes(k),no=no(k);summary.setText(nice(k)+"  •  "+y+" / "+n+" completed  •  "+pct(k)+"%  •  "+no+" no");}
    void setStatus(Task t,String d,int s){t.setStatus(d,s);save();}

    void showDay(String date,String h){selectedDate=date;clear(h);updateSummary(date);
        Button back=btn("←  Monthly view");back.setTextSize(15);back.setOnClickListener(v->showMonth());content.addView(back,new LinearLayout.LayoutParams(-1,66));
        Space g=new Space(this);content.addView(g,new LinearLayout.LayoutParams(1,12));
        Button add=btn("＋  ADD TASK");add.setTextSize(15);add.setOnClickListener(v->editTask(-1));content.addView(add,new LinearLayout.LayoutParams(-1,70));
        content.addView(text("",8));
        for(int i=0;i<tasks.size();i++)dayCard(i,date);
        TextView ct=text("Daily completion  •  "+yes(date)+" / "+total(date)+" = "+pct(date)+"%",23);ct.setPadding(6,24,6,10);content.addView(ct);content.addView(new SingleDayBar(this,pct(date)),new LinearLayout.LayoutParams(-1,58));
    }
    String selectedDate=todayKey();
    void dayCard(int i,String d){Task t=tasks.get(i);
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(14,12,14,12);card.setBackground(round(Color.rgb(248,248,250),22));
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView n=text(t.name,21);n.setTypeface(null,1);n.setMaxLines(2);n.setEllipsize(android.text.TextUtils.TruncateAt.END);row.addView(n,new LinearLayout.LayoutParams(0,68,1));
        Button y=btn(t.status(d)==1?"YES ✓":"YES"),no=btn(t.status(d)==2?"NO ✕":"NO"),clear=btn("—");y.setTextSize(15);no.setTextSize(15);clear.setTextSize(18);styleStatusButton(y,t.status(d)==1?1:0);styleStatusButton(no,t.status(d)==2?2:0);styleStatusButton(clear,0);
        y.setOnClickListener(v->{setStatus(t,d,1);showDay(d,nice(d));});no.setOnClickListener(v->{setStatus(t,d,2);showDay(d,nice(d));});clear.setOnClickListener(v->{setStatus(t,d,0);showDay(d,nice(d));});
        row.addView(y,new LinearLayout.LayoutParams(112,62));row.addView(no,new LinearLayout.LayoutParams(112,62));row.addView(clear,new LinearLayout.LayoutParams(82,62));card.addView(row);
        TextView meta=text(t.category+"  •  "+t.priority+"  •  "+t.repeat,14);meta.setPadding(4,7,4,3);card.addView(meta,new LinearLayout.LayoutParams(-1,34));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,14);content.addView(card,cp);
    }

    void showMonth(){
        int y=monthCursor.get(Calendar.YEAR),m=monthCursor.get(Calendar.MONTH);clear("Monthly Tracker V17");
        content.setPadding(0,14,0,36);
        LinearLayout ctl=new LinearLayout(this);ctl.setPadding(0,6,0,22);
        Button prev=btn("‹");Button cur=btn(new SimpleDateFormat("MMMM yyyy",Locale.US).format(monthCursor.getTime()));Button next=btn("›");
        prev.setTextSize(25);cur.setTextSize(21);next.setTextSize(25);
        prev.setOnClickListener(v->{monthCursor.add(Calendar.MONTH,-1);showMonth();});next.setOnClickListener(v->{monthCursor.add(Calendar.MONTH,1);showMonth();});cur.setOnClickListener(v->{monthCursor=Calendar.getInstance();showMonth();});
        ctl.addView(prev,new LinearLayout.LayoutParams(72,72));ctl.addView(cur,new LinearLayout.LayoutParams(0,72,1));ctl.addView(next,new LinearLayout.LayoutParams(72,72));content.addView(ctl);
        int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH);
        TextView help=text("Monthly task calendar  •  ✓ completed   ✕ not completed   — pending",15);help.setTextSize(16);help.setPadding(6,10,6,22);content.addView(help);
        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setFillViewport(false);hsv.setHorizontalScrollBarEnabled(true);
        LinearLayout matrix=new LinearLayout(this);matrix.setOrientation(LinearLayout.VERTICAL);
        LinearLayout header=new LinearLayout(this);header.setPadding(0,0,0,10);header.addView(cell("TASK",280,true),cellParams(280,104));
        for(int d=1;d<=days;d++){final String k=keyFor(y,m,d);Calendar dc=new GregorianCalendar(y,m,d);String label=d+"\n"+new SimpleDateFormat("EEE",Locale.US).format(dc.getTime()).substring(0,3);Button b=btn(label);b.setTextSize(13);b.setGravity(Gravity.CENTER);b.setPadding(0,0,0,0);b.setOnClickListener(v->showDay(k,nice(k)));header.addView(b,cellParams(112,104));}
        matrix.addView(header);
        if(tasks.isEmpty()){TextView empty=text("No tasks. Add one from Tasks.",17);empty.setPadding(10,20,10,20);matrix.addView(empty);}
        for(Task t:tasks){LinearLayout r=new LinearLayout(this);r.setPadding(0,4,0,10);TextView name=cell(t.name,230,true);name.setTextSize(20);name.setPadding(18,0,18,0);name.setMaxLines(2);name.setEllipsize(android.text.TextUtils.TruncateAt.END);name.setOnClickListener(v->showTaskMonth(t));r.addView(name,cellParams(280,96));for(int d=1;d<=days;d++){String k=keyFor(y,m,d);Button b=btn(mark(t.status(k)));b.setTextSize(25);b.setGravity(Gravity.CENTER);styleStatusButton(b,t.status(k));b.setOnClickListener(v->chooseStatus(t,k));r.addView(b,cellParams(112,96));}matrix.addView(r);}
        hsv.addView(matrix);content.addView(hsv,new LinearLayout.LayoutParams(-1,-2));
        Space gap1=new Space(this);content.addView(gap1,new LinearLayout.LayoutParams(1,34));
        TextView graphTitle=text("Daily completion graph",24);graphTitle.setPadding(4,8,4,14);content.addView(graphTitle);content.addView(graphScroll(new MonthChart(this,y,m),Math.max(1200,days*86),470),new LinearLayout.LayoutParams(-1,470));
        TextView taskGraphTitle=text("Task performance — this month",23);taskGraphTitle.setPadding(6,26,6,10);content.addView(taskGraphTitle);content.addView(text("Completed days out of the full month, compared across all tasks.",14));content.addView(graphScroll(new TaskComparisonChart(this,y,m),Math.max(1200,tasks.size()*190),500),new LinearLayout.LayoutParams(-1,500));
        int sum=0,count=0;for(int d=1;d<=days;d++){String k=keyFor(y,m,d);if(total(k)>0){sum+=pct(k);count++;}}
        TextView avg=text("Month average: "+(count==0?0:sum/count)+"%",24);avg.setTextSize(24);avg.setPadding(6,26,6,24);content.addView(avg);
        Button today=btn("Open today ("+new SimpleDateFormat("dd MMM",Locale.US).format(new Date())+")");today.setTextSize(17);today.setOnClickListener(v->showDay(todayKey(),"Today"));content.addView(today,new LinearLayout.LayoutParams(-1,76));
        content.post(()->hsv.scrollTo(0,0));
    }
    TextView cell(String s,int w,boolean bold){TextView t=text(s,14);t.setGravity(Gravity.CENTER_VERTICAL);if(bold)t.setTypeface(null,1);t.setBackgroundColor(Color.rgb(238,238,242));t.setMinWidth(w);t.setMaxWidth(w);return t;}
    LinearLayout.LayoutParams cellParams(int w,int h){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(w,h);lp.setMargins(2,0,2,0);return lp;}
    String mark(int s){return s==1?"✓":s==2?"✕":"—";}
    void chooseStatus(Task t,String k){new AlertDialog.Builder(this).setTitle(t.name+" • "+nice(k)).setItems(new String[]{"✓ YES / Completed","✕ NO / Not completed","— Pending / Clear"},(d,w)->{setStatus(t,k,w==0?1:w==1?2:0);showMonth();}).show();}
    void showTaskMonth(Task t){int y=monthCursor.get(Calendar.YEAR),m=monthCursor.get(Calendar.MONTH);clear(t.name);content.addView(text(new SimpleDateFormat("MMMM yyyy",Locale.US).format(monthCursor.getTime()),18));int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH);int sum=0;for(int d=1;d<=days;d++){String k=keyFor(y,m,d);if(t.status(k)==1)sum++;content.addView(text(d+"  "+mark(t.status(k))+"   "+pct(k)+"% day total",15));}content.addView(text("Task monthly completion: "+(days==0?0:sum*100/days)+"%",18));}

    void showStats(){clear("Reports");int y=monthCursor.get(Calendar.YEAR),m=monthCursor.get(Calendar.MONTH);int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH);content.addView(text("Daily completion — "+new SimpleDateFormat("MMMM yyyy",Locale.US).format(monthCursor.getTime()),19));content.addView(graphScroll(new MonthChart(this,y,m),Math.max(1200,days*86),470),new LinearLayout.LayoutParams(-1,470));TextView taskGraphTitle=text("Task performance this month",22);taskGraphTitle.setPadding(6,24,6,10);content.addView(taskGraphTitle);content.addView(text("Completed days out of the days in this month. This lets you compare all tasks in one graph.",14));content.addView(graphScroll(new TaskComparisonChart(this,y,m),Math.max(1200,tasks.size()*190),500),new LinearLayout.LayoutParams(-1,500));int sum=0,c=0;for(int d=1;d<=days;d++){String k=keyFor(y,m,d);if(total(k)>0){sum+=pct(k);c++;}}content.addView(text("Monthly average: "+(c==0?0:sum/c)+"%",18));content.addView(text("Yearly monthly averages — "+y,19));content.addView(new YearChart(this,y));}

    void showTasks(){clear("Tasks");Button add=btn("＋  ADD TASK");add.setTextSize(16);add.setOnClickListener(v->editTask(-1));content.addView(add);for(int i=0;i<tasks.size();i++){final int ix=i;LinearLayout r=new LinearLayout(this);TextView n=text(tasks.get(i).name,17);n.setTypeface(null,1);r.addView(n,new LinearLayout.LayoutParams(0,-2,1));Button e=btn("EDIT");e.setOnClickListener(v->editTask(ix));r.addView(e);content.addView(r);}}
    void showMore(){clear("More");
        Button ex=btn("☁  Export backup");ex.setTextSize(16);ex.setOnClickListener(v->exportBackup());content.addView(ex,new LinearLayout.LayoutParams(-1,68));
        Button im=btn("↥  Import backup");im.setTextSize(16);im.setOnClickListener(v->importBackup());content.addView(im,new LinearLayout.LayoutParams(-1,68));
        Button cloud=btn("☁  Cloud / Login");cloud.setTextSize(16);cloud.setOnClickListener(v->cloudInfo());content.addView(cloud,new LinearLayout.LayoutParams(-1,68));
        content.addView(text("Reminders are configured per task. Android notification permission is requested when needed.",15));
        TextView ver=text("Task Tracker V17.0  •  Offline-first",13);ver.setGravity(Gravity.CENTER);ver.setPadding(6,24,6,10);content.addView(ver);
        content.addView(text("Every calendar day is calculated from the full task list: completed tasks ÷ total tasks. Example: 1 of 3 = 33%, 2 of 3 = 67%.",15));
    }
    void cloudInfo(){new AlertDialog.Builder(this).setTitle("Cloud / Login").setMessage("Your data is currently stored offline on this phone. A real cloud login needs a cloud service account and backend configuration; this version does not pretend to provide a fake login. You can use Export backup to save your data to Google Drive, OneDrive, or another cloud storage app.").setPositiveButton("OK",null).show();}

    void editTask(int ix){LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);EditText n=new EditText(this);n.setHint("Task name");EditText c=new EditText(this);c.setHint("Category");EditText note=new EditText(this);note.setHint("Notes");Spinner p=new Spinner(this);p.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"High","Medium","Low"}));Spinner r=new Spinner(this);r.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Once","Daily","Weekly","Monthly"}));Button reminder=btn("⏰ Reminder: Off");final String[] reminderValue={ix>=0?tasks.get(ix).reminder:""};reminder.setOnClickListener(v->pickReminder(reminder,reminderValue));f.addView(n);f.addView(c);f.addView(p);f.addView(r);f.addView(reminder,new LinearLayout.LayoutParams(-1,60));f.addView(note);if(!reminderValue[0].isEmpty())reminder.setText("⏰ Reminder: "+reminderValue[0]);if(ix>=0){Task t=tasks.get(ix);n.setText(t.name);c.setText(t.category);note.setText(t.note);String[] ps={"High","Medium","Low"},rs={"Once","Daily","Weekly","Monthly"};for(int j=0;j<3;j++)if(ps[j].equals(t.priority))p.setSelection(j);for(int j=0;j<4;j++)if(rs[j].equals(t.repeat))r.setSelection(j);}AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle(ix<0?"Add task":"Edit task").setView(f).setPositiveButton("SAVE",(d,w)->{String nn=n.getText().toString().trim();if(nn.isEmpty())return;String cc=c.getText().toString().trim();if(cc.isEmpty())cc="General";Task t;if(ix<0){t=new Task(UUID.randomUUID().toString(),nn,cc,p.getSelectedItem().toString(),r.getSelectedItem().toString(),note.getText().toString().trim(),reminderValue[0]);tasks.add(t);}else{t=tasks.get(ix);t.name=nn;t.category=cc;t.priority=p.getSelectedItem().toString();t.repeat=r.getSelectedItem().toString();t.note=note.getText().toString().trim();t.reminder=reminderValue[0];}save();scheduleReminder(t);showMonth();}).setNegativeButton("CANCEL",null);if(ix>=0)b.setNeutralButton("DELETE",(d,w)->{cancelReminder(tasks.get(ix));tasks.remove(ix);save();showMonth();});b.show();}
    void pickReminder(Button b,String[] val){Calendar now=Calendar.getInstance();TimePickerDialog d=new TimePickerDialog(this,(v,h,m)->{val[0]=String.format(Locale.US,"%02d:%02d",h,m);b.setText("⏰ Reminder: "+val[0]);},now.get(Calendar.HOUR_OF_DAY),now.get(Calendar.MINUTE),true);d.setTitle("Daily reminder time");d.setButton(DialogInterface.BUTTON_NEGATIVE,"OFF",(x,w)->{val[0]="";b.setText("⏰ Reminder: Off");});d.show();}

    void save(){StringBuilder o=new StringBuilder();for(Task t:tasks){StringBuilder h=new StringBuilder();for(Map.Entry<String,Integer>e:t.history.entrySet()){if(h.length()>0)h.append(",");h.append(e.getKey()).append("=").append(e.getValue());}o.append(clean(t.id)).append("|").append(clean(t.name)).append("|").append(clean(t.category)).append("|").append(clean(t.priority)).append("|").append(clean(t.repeat)).append("|").append(clean(t.note)).append("|").append(t.fav?"1":"0").append("|").append(clean(t.reminder)).append("|").append(h).append("\n");}sp.edit().putString("data",o.toString()).apply();}
    String clean(String s){return s.replace("\\","/").replace("|","/").replace("\n"," ").replace(";",",");}
    void load(){String data=sp.getString("data","");if(!data.isEmpty()){parse(data);return;}SharedPreferences old=getSharedPreferences(OLD_PREF_V3,MODE_PRIVATE);String od=old.getString("data","");if(!od.isEmpty()){parseOld(od);save();return;}SharedPreferences v2=getSharedPreferences(OLD_PREF_V2,MODE_PRIVATE);od=v2.getString("data","");if(!od.isEmpty()){parseOld(od);save();return;}SharedPreferences v1=getSharedPreferences(OLD_PREF_V1,MODE_PRIVATE);od=v1.getString("data","");if(!od.isEmpty()){parseOld(od);save();}}
    void parse(String data){for(String line:data.split("\n")){String[]p=line.split("\\|",-1);if(p.length>=8){String rem=p.length>=9?p[7]:"";String hist=p.length>=9?p[8]:p[7];Task t=new Task(p[0],p[1],p[2],p[3],p[4],p[5],rem);t.fav=p[6].equals("1");if(!hist.isEmpty())for(String e:hist.split(",")){String[]q=e.split("=",-1);if(q.length==2)try{t.history.put(q[0],Integer.parseInt(q[1]));}catch(Exception ignored){}}tasks.add(t);}}}
    void parseOld(String data){for(String line:data.split("\n")){String[]p=line.split("\\|",-1);if(p.length>=8){Task t=new Task(p[0],p[1],p[2],p[3],p[4],p[5]);t.fav=p[7].equals("1");t.setStatus(todayKey(),p[6].equals("1")?1:0);tasks.add(t);}}}
    void exportBackup(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/plain");i.putExtra(Intent.EXTRA_TITLE,"TaskTracker_V17_Backup.txt");startActivityForResult(i,77);}
    void importBackup(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("text/plain");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,78);}
    protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;try{if(req==77){OutputStream out=getContentResolver().openOutputStream(data.getData());out.write(sp.getString("data","").getBytes("UTF-8"));out.close();Toast.makeText(this,"Backup exported",Toast.LENGTH_SHORT).show();}else if(req==78){BufferedReader br=new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(data.getData()),"UTF-8"));StringBuilder sb=new StringBuilder();String l;while((l=br.readLine())!=null)sb.append(l).append('\n');br.close();sp.edit().putString("data",sb.toString()).apply();tasks.clear();load();showMonth();Toast.makeText(this,"Backup restored",Toast.LENGTH_SHORT).show();}}catch(Exception e){Toast.makeText(this,"Backup operation failed",Toast.LENGTH_SHORT).show();}}

    void createNotificationChannel(){if(Build.VERSION.SDK_INT>=26){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);NotificationChannel ch=new NotificationChannel("task_reminders","Task reminders",NotificationManager.IMPORTANCE_DEFAULT);ch.setDescription("Daily task reminders");nm.createNotificationChannel(ch);}}
    int reminderId(Task t){return Math.abs(t.id.hashCode());}
    void scheduleAllReminders(){for(Task t:tasks)scheduleReminder(t);}
    void cancelReminder(Task t){AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);Intent in=new Intent(this,ReminderReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(this,reminderId(t),in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);am.cancel(pi);}
    void scheduleReminder(Task t){cancelReminder(t);if(t.reminder==null||t.reminder.isEmpty())return;try{String[] q=t.reminder.split(":");Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,Integer.parseInt(q[0]));c.set(Calendar.MINUTE,Integer.parseInt(q[1]));c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);if(c.before(Calendar.getInstance()))c.add(Calendar.DAY_OF_YEAR,1);Intent in=new Intent(this,ReminderReceiver.class);in.putExtra("taskName",t.name);in.putExtra("taskId",t.id);PendingIntent pi=PendingIntent.getBroadcast(this,reminderId(t),in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);am.setInexactRepeating(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);}catch(Exception ignored){}}

    class SingleDayBar extends View{Paint p=new Paint(1);int v;SingleDayBar(Context c,int x){super(c);v=x;setMinimumHeight(50);}protected void onDraw(Canvas c){float l=15,r=getWidth()-15;p.setColor(Color.LTGRAY);c.drawRoundRect(l,12,r,36,12,12,p);p.setColor(PURPLE);c.drawRoundRect(l,12,l+(r-l)*v/100f,36,12,12,p);p.setColor(Color.DKGRAY);p.setTextSize(13);c.drawText(v+"%",20,30,p);}}
    class MonthChart extends View{
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);int y,m;
        MonthChart(Context c,int yy,int mm){super(c);y=yy;m=mm;setLayerType(View.LAYER_TYPE_HARDWARE,null);setMinimumHeight(470);}
        protected void onDraw(Canvas c){
            super.onDraw(c); c.drawColor(Color.WHITE);
            float l=64,t=48,r=getWidth()-30,b=getHeight()-62; int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH);
            p.setTypeface(Typeface.DEFAULT);
            for(int q=0;q<=4;q++){float yy=b-(b-t)*q/4f;p.setColor(Color.rgb(225,229,235));p.setStrokeWidth(2);c.drawLine(l,yy,r,yy,p);p.setColor(Color.rgb(90,96,105));p.setTextSize(14);c.drawText((q*25)+"%",10,yy+5,p);}
            float slot=(r-l)/Math.max(1,days);
            ArrayList<Float> xs=new ArrayList<>();ArrayList<Float> ys=new ArrayList<>();
            for(int d=1;d<=days;d++){String k=keyFor(y,m,d);int v=pct(k);boolean future=isFuture(k);float x=l+(d-0.5f)*slot;float yy=future?b:b-(b-t)*v/100f;xs.add(x);ys.add(yy);}
            // smooth-looking wave through daily completion points
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);p.setColor(Color.rgb(79,70,229));
            Path path=new Path();boolean started=false;for(int i=0;i<xs.size();i++){if(isFuture(keyFor(y,m,i+1))){continue;}if(!started){path.moveTo(xs.get(i),ys.get(i));started=true;}else{float px=xs.get(i-1),py=ys.get(i-1),cx=xs.get(i),cy=ys.get(i);float mid=(px+cx)/2f;path.cubicTo(mid,py,mid,cy,cx,cy);}}if(started)c.drawPath(path,p);
            p.setStyle(Paint.Style.FILL);
            for(int d=1;d<=days;d++){String k=keyFor(y,m,d);if(isFuture(k))continue;int v=pct(k);float x=xs.get(d-1),yy=ys.get(d-1);p.setColor(v>=75?Color.rgb(22,163,74):v>=40?Color.rgb(245,158,11):v>0?Color.rgb(239,68,68):Color.rgb(156,163,175));c.drawCircle(x,yy,6,p);p.setColor(Color.rgb(45,48,55));p.setTextSize(12);String val=v+"%";float vw=p.measureText(val);c.drawText(val,x-vw/2,Math.max(t+18,yy-12),p);p.setTextSize(11);c.drawText(""+d,x-p.measureText(""+d)/2,b+22,p);}
            p.setColor(Color.rgb(80,85,95));p.setTextSize(14);c.drawText("Daily completion wave • completed tasks ÷ total tasks for that date",l,t-20,p);
            p.setStyle(Paint.Style.FILL);
        }
    }
    class TaskComparisonChart extends View{
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);int y,m;
        int[] colors={Color.rgb(59,130,246),Color.rgb(16,185,129),Color.rgb(245,158,11),Color.rgb(239,68,68),Color.rgb(168,85,247),Color.rgb(14,165,233),Color.rgb(236,72,153)};
        TaskComparisonChart(Context c,int yy,int mm){super(c);y=yy;m=mm;setMinimumHeight(470);setLayerType(View.LAYER_TYPE_HARDWARE,null);}
        protected void onDraw(Canvas c){
            super.onDraw(c);c.drawColor(Color.WHITE);float l=64,t=40,r=getWidth()-26,b=getHeight()-95;int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH);
            for(int q=0;q<=4;q++){float yy=b-(b-t)*q/4f;p.setColor(Color.rgb(225,229,235));p.setStrokeWidth(2);c.drawLine(l,yy,r,yy,p);p.setColor(Color.rgb(85,90,100));p.setTextSize(14);c.drawText((q*25)+"%",12,yy+5,p);}
            if(tasks.size()==0){p.setColor(Color.DKGRAY);p.setTextSize(18);c.drawText("Add tasks to see comparison.",l,t+30,p);return;}
            float slot=(r-l)/Math.max(1,tasks.size());float bw=Math.min(120,slot*0.58f);
            for(int i=0;i<tasks.size();i++){
                Task task=tasks.get(i);int done=0;for(int d=1;d<=days;d++)if(task.status(keyFor(y,m,d))==1)done++;int v=Math.round(done*100f/days);
                float x=l+i*slot+(slot-bw)/2f;float h=(b-t)*v/100f;p.setColor(colors[i%colors.length]);c.drawRoundRect(x,b-h,x+bw,b,14,14,p);
                p.setColor(Color.rgb(35,38,45));p.setTextSize(15);String val=done+"/"+days+"  "+v+"%";float vw=p.measureText(val);c.drawText(val,x+bw/2-vw/2,Math.max(t+18,b-h-10),p);
                String nm=task.name; if(nm.length()>15)nm=nm.substring(0,14)+"…";p.setTextSize(13);float nw=p.measureText(nm);c.drawText(nm,x+bw/2-nw/2,b+24,p);
            }
            p.setTextSize(14);p.setColor(Color.rgb(80,85,95));c.drawText("Task performance = completed days out of the full month",l,t-12,p);
        }
    }
    class YearChart extends View{Paint p=new Paint(1);int y;YearChart(Context c,int yy){super(c);y=yy;setMinimumHeight(270);}protected void onDraw(Canvas c){float l=35,t=15,r=getWidth()-10,b=getHeight()-30;float bw=(r-l)/12f-5;p.setColor(Color.GRAY);c.drawLine(l,b,r,b,p);for(int m=0;m<12;m++){int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH);int s=0,n=0;for(int d=1;d<=days;d++){String k=keyFor(y,m,d);if(total(k)>0){s+=pct(k);n++;}}int v=n==0?0:s/n;float x=l+m*(r-l)/12f+2;float h=(b-t)*v/100f;p.setColor(PURPLE);c.drawRect(x,b-h,x+bw,b,p);p.setColor(Color.GRAY);p.setTextSize(8);c.drawText(new SimpleDateFormat("MMM",Locale.US).format(new GregorianCalendar(y,m,1).getTime()),x,b+14,p);if(v>0)c.drawText(""+v,x,b-h-3,p);}}}
}

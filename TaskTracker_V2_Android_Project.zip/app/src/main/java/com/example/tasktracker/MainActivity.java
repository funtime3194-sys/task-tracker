package com.example.tasktracker;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    TextView header;
    ArrayList<Task> tasks = new ArrayList<>();
    android.content.SharedPreferences sp;
    int purple = Color.rgb(79,70,229);
    static class Task {
        String name, cat, repeat, note;
        boolean done, fav;
        Task(String n,String c,String r,String no){name=n;cat=c;repeat=r;note=no;}
    }
    TextView tv(String s,int size){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(Color.rgb(30,30,40)); t.setPadding(16,12,16,12); return t;
    }
    public void onCreate(Bundle b){
        super.onCreate(b); sp=getSharedPreferences("v2",0); load();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},5);
        buildShell(); showToday();
    }
    void buildShell(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(12,20,12,8);
        header=tv("Task Tracker",27); header.setTypeface(null,1); root.addView(header);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this);
        String[] labels={"Today","Reports","Favourites","History"};
        for(String s:labels){Button b=new Button(this); b.setText(s); b.setOnClickListener(v->{if(s.equals("Today"))showToday();else if(s.equals("Reports"))showReports();else if(s.equals("Favourites"))showFav();else showHistory();}); nav.addView(b,new LinearLayout.LayoutParams(0,58,1));}
        root.addView(nav); setContentView(root);
    }
    void clear(String title){header.setText(title); content.removeAllViews();}
    Button button(String s){Button b=new Button(this);b.setText(s);return b;}
    void showToday(){
        clear("Today");
        int done=countDone(), n=tasks.size(), pct=n==0?0:done*100/n;
        TextView p=tv(done+"/"+n+" completed  •  "+pct+"%",18); content.addView(p);
        Button add=button("+ Add task"); add.setOnClickListener(v->addTask()); content.addView(add);
        if(tasks.isEmpty()) content.addView(tv("No tasks yet. Add your first task.",17));
        for(int i=0;i<tasks.size();i++){
            final int ix=i; Task a=tasks.get(i);
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            CheckBox c=new CheckBox(this); c.setText(a.name+"  ["+a.cat+"]"); c.setTextSize(16); c.setChecked(a.done);
            c.setOnCheckedChangeListener((x,v)->{a.done=v;save();showToday();});
            row.addView(c,new LinearLayout.LayoutParams(0,-2,1));
            Button f=button(a.fav?"★":"☆"); f.setOnClickListener(v->{a.fav=!a.fav;save();showToday();}); row.addView(f);
            Button d=button("⋮"); d.setOnClickListener(v->editTask(ix)); row.addView(d);
            content.addView(row);
        }
    }
    void addTask(){ editTask(-1); }
    void editTask(int ix){
        LinearLayout form=new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL);
        EditText name=new EditText(this); name.setHint("Task name");
        EditText cat=new EditText(this); cat.setHint("Category (Study, Health...)");
        EditText note=new EditText(this); note.setHint("Note (optional)");
        Spinner repeat=new Spinner(this); String[] rs={"Once","Daily","Weekly","Monthly"}; repeat.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,rs));
        form.addView(name);form.addView(cat);form.addView(note);form.addView(repeat);
        if(ix>=0){Task a=tasks.get(ix);name.setText(a.name);cat.setText(a.cat);note.setText(a.note);for(int j=0;j<rs.length;j++)if(rs[j].equals(a.repeat))repeat.setSelection(j);}
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle(ix<0?"Add task":"Edit task").setView(form)
          .setPositiveButton("Save",(d,w)->{String n=name.getText().toString().trim();if(n.length()==0)return;Task a=ix<0?new Task(n,cat.getText().toString().trim(),repeat.getSelectedItem().toString(),note.getText().toString().trim()):tasks.get(ix);a.name=n;a.cat=cat.getText().toString().trim().length()==0?"General":cat.getText().toString().trim();a.repeat=repeat.getSelectedItem().toString();a.note=note.getText().toString().trim();save();showToday();})
          .setNegativeButton("Cancel",null).create();
        if(ix>=0) dlg.setOnShowListener(x->{Button del=dlg.getButton(AlertDialog.BUTTON_NEGATIVE); del.setText("Close");}); dlg.show();
    }
    void showReports(){
        clear("Monthly Report");
        int n=tasks.size(),done=countDone(),pct=n==0?0:done*100/n;
        content.addView(tv("Current completion: "+pct+"%",22));
        content.addView(tv("Completed: "+done+"   •   Pending: "+(n-done),17));
        content.addView(tv("★ Favourites: "+countFav(),17));
        content.addView(tv("⚠ Needs attention: "+(n-done),17));
        content.addView(tv("Categories",20));
        HashMap<String,Integer> total=new HashMap<>(), ok=new HashMap<>();
        for(Task t:tasks){total.put(t.cat,total.getOrDefault(t.cat,0)+1);if(t.done)ok.put(t.cat,ok.getOrDefault(t.cat,0)+1);}
        for(String c:total.keySet()){int z=ok.getOrDefault(c,0)*100/total.get(c);content.addView(tv(c+"  —  "+z+"% ("+ok.getOrDefault(c,0)+"/"+total.get(c)+")",16));}
        content.addView(tv("\nPerformance is based on your recorded tasks. More history will make this report more informative.",15));
    }
    void showFav(){
        clear("Favourite Tasks");
        boolean any=false; for(Task t:tasks)if(t.fav){any=true;content.addView(tv((t.done?"✓ ":"○ ")+t.name+"  •  "+t.cat,17));}
        if(!any)content.addView(tv("No favourite tasks yet. Tap ☆ beside a task to add it.",17));
    }
    void showHistory(){
        clear("History");
        content.addView(tv("Today: "+countDone()+"/"+tasks.size()+" completed",18));
        content.addView(tv("Tasks currently marked complete:",19));
        for(Task t:tasks)if(t.done)content.addView(tv("✓ "+t.name+"  ["+t.cat+"]",16));
        if(countDone()==0)content.addView(tv("No completed tasks yet.",16));
        content.addView(tv("\nFor detailed day-by-day history, continue using the app; future versions can add calendar history and export.",15));
    }
    int countDone(){int x=0;for(Task t:tasks)if(t.done)x++;return x;}
    int countFav(){int x=0;for(Task t:tasks)if(t.fav)x++;return x;}
    void save(){StringBuilder q=new StringBuilder();for(Task t:tasks)q.append(enc(t.name)).append("|").append(enc(t.cat)).append("|").append(enc(t.repeat)).append("|").append(enc(t.note)).append("|").append(t.done?"1":"0").append("|").append(t.fav?"1":"0").append("\n");sp.edit().putString("data",q.toString()).apply();}
    String enc(String s){return s.replace("\\","\\\\").replace("|","/").replace("\n"," ");}
    void load(){String q=sp.getString("data","");for(String s:q.split("\n")){if(s.trim().isEmpty())continue;String[] p=s.split("\\|",-1);if(p.length>=6){Task t=new Task(p[0],p[1],p[2],p[3]);t.done=p[4].equals("1");t.fav=p[5].equals("1");tasks.add(t);}}}
}
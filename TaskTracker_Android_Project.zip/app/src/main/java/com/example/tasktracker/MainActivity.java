package com.example.tasktracker;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout list; TextView progress, report; ArrayList<Task> tasks=new ArrayList<>(); android.content.SharedPreferences sp;
    static class Task { String name,cat; boolean done,fav; Task(String n,String c){name=n;cat=c;} }
    public void onCreate(Bundle b){super.onCreate(b); sp=getSharedPreferences("tasks",0); load(); build();}
    TextView tv(String s,int z){ TextView t=new TextView(this); t.setText(s); t.setTextSize(z); t.setTextColor(Color.rgb(30,30,40)); t.setPadding(18,14,18,14); return t; }
    void build(){
      LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(12,20,12,12);
      TextView title=tv("Task Tracker",26); title.setTypeface(null,1); root.addView(title);
      progress=tv("",17); root.addView(progress);
      Button add=new Button(this); add.setText("+ Add task"); add.setOnClickListener(v->addTask()); root.addView(add);
      list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
      ScrollView sv=new ScrollView(this); sv.addView(list); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
      report=tv("",16); root.addView(report);
      setContentView(root); refresh();
    }
    void addTask(){
      final EditText e=new EditText(this); e.setHint("Task name");
      new AlertDialog.Builder(this).setTitle("New task").setView(e).setPositiveButton("Add",(d,w)->{if(e.getText().length()>0){tasks.add(new Task(e.getText().toString(),"General"));save();refresh();}}).setNegativeButton("Cancel",null).show();
    }
    void refresh(){
      list.removeAllViews(); int done=0;
      for(int i=0;i<tasks.size();i++){ final int x=i; Task a=tasks.get(i); if(a.done)done++;
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        CheckBox c=new CheckBox(this); c.setChecked(a.done); c.setText(a.name); c.setTextSize(17); c.setOnCheckedChangeListener((b,v)->{a.done=v;save();refresh();});
        row.addView(c,new LinearLayout.LayoutParams(0,-2,1));
        Button f=new Button(this); f.setText(a.fav?"★":"☆"); f.setOnClickListener(v->{a.fav=!a.fav;save();refresh();}); row.addView(f);
        Button del=new Button(this); del.setText("×"); del.setOnClickListener(v->{tasks.remove(x);save();refresh();}); row.addView(del);
        list.addView(row);
      }
      int n=tasks.size(), pct=n==0?0:done*100/n; progress.setText("Today  •  "+done+"/"+n+" completed ("+pct+"%)");
      long fav=tasks.stream().filter(t->t.fav).count(), weak=tasks.stream().filter(t->!t.done).count();
      report.setText("★ Favourites: "+fav+"    •    Needs attention: "+weak+"\nMonthly report: "+pct+"% current completion");
    }
    void save(){ StringBuilder q=new StringBuilder(); for(Task t:tasks)q.append(t.name.replace("|"," ")).append("|").append(t.done?"1":"0").append("|").append(t.fav?"1":"0").append("\n"); sp.edit().putString("data",q.toString()).apply();}
    void load(){String q=sp.getString("data",""); for(String s:q.split("\n")){if(s.trim().isEmpty())continue;String[] p=s.split("\\|");if(p.length>=3){Task t=new Task(p[0],"General");t.done=p[1].equals("1");t.fav=p[2].equals("1");tasks.add(t);}}}
}
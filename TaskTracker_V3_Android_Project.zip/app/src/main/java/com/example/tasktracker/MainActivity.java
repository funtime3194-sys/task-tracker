package com.example.tasktracker;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    static final String PREF = "task_tracker_v3";
    static final int PURPLE = Color.rgb(79,70,229);
    LinearLayout content;
    TextView title, summary;
    ArrayList<Task> tasks = new ArrayList<>();
    SharedPreferences sp;

    static class Task {
        String id, name, category, priority, repeat, note, due;
        boolean done, fav;
        Task(String id,String name,String category,String priority,String repeat,String note,String due){
            this.id=id; this.name=name; this.category=category; this.priority=priority;
            this.repeat=repeat; this.note=note; this.due=due;
        }
    }

    public void onCreate(Bundle b) {
        super.onCreate(b);
        sp=getSharedPreferences(PREF,MODE_PRIVATE);
        load();
        if (Build.VERSION.SDK_INT>=33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 10);
        buildShell();
        showToday();
    }

    TextView text(String s,int size) {
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(25,25,35));
        t.setPadding(16,10,16,10);
        return t;
    }

    Button navButton(String label) {
        Button b=new Button(this);
        b.setText(label); b.setTextSize(11);
        return b;
    }

    void buildShell() {
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(12,18,12,8);

        title=text("Task Tracker V3",27);
        title.setTypeface(null,1);
        root.addView(title);

        summary=text("",16);
        root.addView(summary);

        content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);

        ScrollView scroll=new ScrollView(this);
        scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav=new LinearLayout(this);
        nav.setBackgroundColor(Color.rgb(245,245,248));
        String[] labels={"Today","Reports","Favourites","History"};
        for(String label:labels) {
            Button b=navButton(label);
            b.setOnClickListener(v -> {
                if(label.equals("Today")) showToday();
                else if(label.equals("Reports")) showReports();
                else if(label.equals("Favourites")) showFavourites();
                else showHistory();
            });
            nav.addView(b,new LinearLayout.LayoutParams(0,62,1));
        }
        root.addView(nav);

        setContentView(root);
    }

    void clear(String heading) {
        title.setText(heading);
        content.removeAllViews();
    }

    Button action(String s) {
        Button b=new Button(this); b.setText(s); return b;
    }

    int total(){ return tasks.size(); }
    int completed(){ int n=0; for(Task t:tasks) if(t.done)n++; return n; }
    int favourites(){ int n=0; for(Task t:tasks) if(t.fav)n++; return n; }
    int completion(){ return total()==0?0:(completed()*100/total()); }

    void updateSummary() {
        summary.setText("Today: "+completed()+"/"+total()+" completed  •  "+completion()+"%");
    }

    void showToday() {
        clear("Today");
        updateSummary();

        Button add=action("+ ADD TASK");
        add.setOnClickListener(v->editTask(-1));
        content.addView(add);

        if(tasks.isEmpty()) content.addView(text("No tasks yet. Add your first task.",17));

        for(int i=0;i<tasks.size();i++) {
            final int ix=i; Task t=tasks.get(i);
            LinearLayout card=new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(4,6,4,6);

            LinearLayout row=new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);

            CheckBox box=new CheckBox(this);
            box.setText(t.name);
            box.setTextSize(17);
            box.setChecked(t.done);
            box.setOnCheckedChangeListener((v,checked)->{
                t.done=checked; save(); showToday();
            });
            row.addView(box,new LinearLayout.LayoutParams(0,-2,1));

            Button fav=action(t.fav?"★":"☆");
            fav.setOnClickListener(v->{t.fav=!t.fav;save();showToday();});
            row.addView(fav);

            Button edit=action("Edit");
            edit.setOnClickListener(v->editTask(ix));
            row.addView(edit);

            card.addView(row);
            String meta=t.category+" • "+t.priority+" • "+t.repeat;
            if(!t.note.isEmpty()) meta += "\n"+t.note;
            card.addView(text(meta,13));
            content.addView(card);
        }
    }

    void editTask(int ix) {
        LinearLayout form=new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);

        EditText name=new EditText(this); name.setHint("Task name");
        EditText category=new EditText(this); category.setHint("Category");
        EditText note=new EditText(this); note.setHint("Notes (optional)");

        Spinner priority=new Spinner(this);
        String[] ps={"High","Medium","Low"};
        priority.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,ps));

        Spinner repeat=new Spinner(this);
        String[] rs={"Once","Daily","Weekly","Monthly"};
        repeat.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,rs));

        form.addView(name); form.addView(category); form.addView(priority);
        form.addView(repeat); form.addView(note);

        if(ix>=0) {
            Task t=tasks.get(ix);
            name.setText(t.name); category.setText(t.category); note.setText(t.note);
            for(int j=0;j<ps.length;j++) if(ps[j].equals(t.priority)) priority.setSelection(j);
            for(int j=0;j<rs.length;j++) if(rs[j].equals(t.repeat)) repeat.setSelection(j);
        }

        AlertDialog.Builder builder=new AlertDialog.Builder(this)
            .setTitle(ix<0?"Add task":"Edit task")
            .setView(form)
            .setPositiveButton("Save",(d,w)->{
                String n=name.getText().toString().trim();
                if(n.isEmpty()) return;
                String c=category.getText().toString().trim();
                if(c.isEmpty()) c="General";

                if(ix<0) {
                    Task t=new Task(UUID.randomUUID().toString(),n,c,
                        priority.getSelectedItem().toString(),
                        repeat.getSelectedItem().toString(),
                        note.getText().toString().trim(),"");
                    tasks.add(t);
                } else {
                    Task t=tasks.get(ix);
                    t.name=n; t.category=c;
                    t.priority=priority.getSelectedItem().toString();
                    t.repeat=repeat.getSelectedItem().toString();
                    t.note=note.getText().toString().trim();
                }
                save(); showToday();
            })
            .setNegativeButton("Cancel",null);

        if(ix>=0) {
            builder.setNeutralButton("Delete",(d,w)->{
                tasks.remove(ix); save(); showToday();
            });
        }
        builder.show();
    }

    void showReports() {
        clear("Monthly Report");
        updateSummary();

        content.addView(text("Completion overview",20));
        content.addView(text("Completed: "+completed(),17));
        content.addView(text("Pending: "+(total()-completed()),17));
        content.addView(text("Completion: "+completion()+"%",17));
        content.addView(text("Favourites: "+favourites(),17));

        int missed=total()-completed();
        content.addView(text("Needs attention: "+missed,17));

        content.addView(text("\nTask performance",20));
        HashMap<String,int[]> map=new HashMap<>();
        for(Task t:tasks) {
            if(!map.containsKey(t.category)) map.put(t.category,new int[]{0,0});
            map.get(t.category)[0]++;
            if(t.done) map.get(t.category)[1]++;
        }
        for(String c:map.keySet()) {
            int[] a=map.get(c);
            int p=a[0]==0?0:a[1]*100/a[0];
            content.addView(text(c+"  •  "+p+"%  ("+a[1]+"/"+a[0]+")",16));
        }

        content.addView(text("\nNote: detailed day-by-day graphs require stored completion history. V3 records the current task state; a later update can add full calendar analytics without changing your task data.",14));
    }

    void showFavourites() {
        clear("Favourite Tasks");
        updateSummary();
        boolean any=false;
        for(Task t:tasks) if(t.fav) {
            any=true;
            content.addView(text((t.done?"✓ ":"○ ")+t.name+"\n"+t.category+" • "+t.priority,17));
        }
        if(!any) content.addView(text("No favourite tasks. Tap ☆ beside a task to add one.",17));
    }

    void showHistory() {
        clear("History");
        updateSummary();
        content.addView(text("Current task status",20));
        if(tasks.isEmpty()) {
            content.addView(text("No task history yet.",17));
            return;
        }
        for(Task t:tasks) {
            content.addView(text((t.done?"✓ Completed: ":"○ Pending: ")+t.name+"\n"+t.category+" • "+t.repeat,16));
        }
    }

    String clean(String s) {
        return s.replace("\\","/").replace("|","/").replace("\n"," ");
    }

    void save() {
        StringBuilder out=new StringBuilder();
        for(Task t:tasks) {
            out.append(clean(t.id)).append("|").append(clean(t.name)).append("|")
               .append(clean(t.category)).append("|").append(clean(t.priority)).append("|")
               .append(clean(t.repeat)).append("|").append(clean(t.note)).append("|")
               .append(t.done?"1":"0").append("|").append(t.fav?"1":"0").append("\n");
        }
        sp.edit().putString("data",out.toString()).apply();
    }

    void load() {
        String data=sp.getString("data","");
        if(!data.isEmpty()) {
            for(String line:data.split("\n")) {
                String[] p=line.split("\\|",-1);
                if(p.length>=8) {
                    Task t=new Task(p[0],p[1],p[2],p[3],p[4],p[5],"");
                    t.done=p[6].equals("1"); t.fav=p[7].equals("1"); tasks.add(t);
                }
            }
            return;
        }

        // Migrate V2 data if present.
        SharedPreferences old=getSharedPreferences("v2",MODE_PRIVATE);
        String oldData=old.getString("data","");
        if(!oldData.isEmpty()) {
            for(String line:oldData.split("\n")) {
                String[] p=line.split("\\|",-1);
                if(p.length>=6) {
                    Task t=new Task(UUID.randomUUID().toString(),p[0],
                        p[1].isEmpty()?"General":p[1],"Medium",
                        p[2].isEmpty()?"Once":p[2],p[3],"");
                    t.done=p[4].equals("1"); t.fav=p[5].equals("1"); tasks.add(t);
                }
            }
            save(); return;
        }

        // Migrate V1 data if present.
        SharedPreferences v1=getSharedPreferences("tasks",MODE_PRIVATE);
        String v1Data=v1.getString("data","");
        if(!v1Data.isEmpty()) {
            for(String line:v1Data.split("\n")) {
                String[] p=line.split("\\|",-1);
                if(p.length>=3) {
                    Task t=new Task(UUID.randomUUID().toString(),p[0],"General","Medium","Once","",
                        "");
                    t.done=p[1].equals("1"); t.fav=p[2].equals("1"); tasks.add(t);
                }
            }
            save();
        }
    }
}
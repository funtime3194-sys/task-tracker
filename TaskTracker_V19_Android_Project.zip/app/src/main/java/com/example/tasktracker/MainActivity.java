package com.example.tasktracker;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteException;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.text.InputType;
import android.text.TextUtils;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    static final int PURPLE = Color.rgb(79,70,229), PURPLE_DARK = Color.rgb(55,48,163), GREEN = Color.rgb(22,163,74), RED = Color.rgb(220,38,38), AMBER = Color.rgb(217,119,6), TEXT = Color.rgb(31,32,43), MUTED = Color.rgb(103,108,125), BG = Color.rgb(247,247,250), CARD = Color.WHITE;
    static final String LEGACY_PREF = "task_tracker_v4";
    static final String OLD_PREF_V3 = "task_tracker_v3", OLD_PREF_V2 = "v2", OLD_PREF_V1 = "tasks";

    LinearLayout root, content, nav;
    TextView title, summary;
    TaskDbHelper db;
    ArrayList<Task> tasks = new ArrayList<>();
    Calendar monthCursor = Calendar.getInstance();
    final SimpleDateFormat dayKey = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
    final SimpleDateFormat niceDate = new SimpleDateFormat("EEE, dd MMM yyyy", Locale.US);
    String selectedDate;
    int currentTab = 1;
    String taskFilter = "All";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        selectedDate = todayKey();
        db = new TaskDbHelper(this);
        migrateLegacyIfNeeded();
        tasks.addAll(db.loadTasks());
        setupWindow();
        createNotificationChannel();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 500);
        buildShell();
        showToday();
        scheduleAllReminders();
    }

    void setupWindow() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
    }

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    TextView tv(String s, float sp) { TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(TEXT); t.setIncludeFontPadding(false); return t; }
    Button button(String s) { Button b = new Button(this); b.setText(s); b.setTextSize(14); b.setAllCaps(false); b.setTextColor(TEXT); b.setGravity(Gravity.CENTER); b.setPadding(dp(8), 0, dp(8), 0); b.setStateListAnimator(null); b.setBackground(round(Color.rgb(239,240,244), dp(16))); b.setMinHeight(dp(46)); return b; }
    GradientDrawable round(int color, int radius) { GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }
    GradientDrawable stroke(int fill, int line, int radius, int width) { GradientDrawable g = round(fill, radius); g.setStroke(width, line); return g; }

    void buildShell() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG); root.setClipToPadding(false); root.setClipChildren(false);
        root.setPadding(dp(10), dp(0), dp(10), 0);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                v.setPadding(dp(10), bars.top, dp(10), bars.bottom);
            }
            return insets;
        });

        LinearLayout appbar = new LinearLayout(this); appbar.setGravity(Gravity.CENTER_VERTICAL); appbar.setPadding(dp(4),0,dp(4),0);
        Button menu = button("☰"); menu.setTextSize(21); menu.setBackground(round(Color.TRANSPARENT, 0)); menu.setOnClickListener(v -> showMore());
        appbar.addView(menu, new LinearLayout.LayoutParams(dp(52), dp(64)));
        title = tv("Task Tracker", 24); title.setTypeface(Typeface.DEFAULT_BOLD); title.setGravity(Gravity.CENTER); appbar.addView(title, new LinearLayout.LayoutParams(0, dp(64), 1));
        Button quick = button("＋"); quick.setTextSize(23); quick.setTextColor(PURPLE_DARK); quick.setBackground(round(Color.TRANSPARENT, 0)); quick.setOnClickListener(v -> editTask(-1));
        appbar.addView(quick, new LinearLayout.LayoutParams(dp(52), dp(64)));
        root.addView(appbar);

        summary = tv("", 13); summary.setTextColor(MUTED); summary.setGravity(Gravity.CENTER); summary.setSingleLine(true); summary.setEllipsize(TextUtils.TruncateAt.END); summary.setBackground(round(Color.rgb(239,239,246), dp(14))); LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, dp(40)); slp.setMargins(0,0,0,dp(8)); root.addView(summary, slp);

        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(0,0,0,dp(28));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setClipToPadding(false); scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));

        nav = new LinearLayout(this); nav.setPadding(dp(4),dp(4),dp(4),dp(4)); nav.setBackground(round(Color.WHITE, dp(18))); nav.setElevation(dp(3));
        String[] names = {"Today","Month","Stats","Tasks","More"};
        for (int i=0;i<names.length;i++) { final int idx=i; Button n=button(names[i]); n.setTextSize(14); n.setOnClickListener(v -> { currentTab=idx; refreshNav(); if(idx==0)showToday(); else if(idx==1)showMonth(); else if(idx==2)showStats(); else if(idx==3)showTasks(); else showMore(); }); nav.addView(n,new LinearLayout.LayoutParams(0,dp(54),1)); }
        root.addView(nav,new LinearLayout.LayoutParams(-1,dp(62)));
        setContentView(root); root.requestApplyInsets(); refreshNav();
    }

    void refreshNav() { if(nav==null)return; for(int i=0;i<nav.getChildCount();i++){ Button b=(Button)nav.getChildAt(i); b.setTextColor(i==currentTab?PURPLE_DARK:MUTED); b.setTypeface(i==currentTab?Typeface.DEFAULT_BOLD:Typeface.DEFAULT); b.setBackground(round(i==currentTab?Color.rgb(232,231,255):Color.TRANSPARENT,dp(14))); } }
    void clearScreen(String h) { title.setText(h); content.removeAllViews(); content.setAlpha(1f); content.setTranslationY(0); updateSummary(selectedDate); refreshNav(); }
    String todayKey(){ return dayKey.format(new Date()); }
    String keyFor(int y,int m,int d){ Calendar c=new GregorianCalendar(y,m,d); return dayKey.format(c.getTime()); }
    String nice(String k){ try{return niceDate.format(dayKey.parse(k));}catch(Exception e){return k;} }
    boolean isFuture(String k){ return k.compareTo(todayKey())>0; }
    int total(String k){ return isFuture(k)?0:tasks.size(); }
    int yes(String k){ int n=0; for(Task t:tasks)if(t.status(k)==1)n++; return n; }
    int no(String k){ int n=0; for(Task t:tasks)if(t.status(k)==2)n++; return n; }
    int pending(String k){ int n=0,total=total(k); for(Task t:tasks)if(t.status(k)==0)n++; return Math.max(0, Math.min(n,total)); }
    int pct(String k){ int n=total(k); return n==0?0:Math.round(yes(k)*100f/n); }
    int monthAverage(int y,int m){ int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH), s=0,n=0; for(int d=1;d<=days;d++){String k=keyFor(y,m,d);if(total(k)>0){s+=pct(k);n++;}} return n==0?0:Math.round((float)s/n); }
    int taskPct(Task t,int y,int m){ int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH), done=0; for(int d=1;d<=days;d++){String k=keyFor(y,m,d);if(t.status(k)==1)done++;} return days==0?0:Math.round(done*100f/days); }
    int completedDays(Task t,int y,int m){int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH),done=0;for(int d=1;d<=days;d++)if(t.status(keyFor(y,m,d))==1)done++;return done;}
    void updateSummary(String k){ summary.setText(nice(k)+"  •  "+yes(k)+" / "+total(k)+" completed  •  "+pct(k)+"%  •  "+no(k)+" not completed"); }

    LinearLayout section(String heading, String sub) { LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(4),dp(10),dp(4),dp(8)); TextView h=tv(heading,24);h.setTypeface(Typeface.DEFAULT_BOLD);box.addView(h); if(sub!=null&&!sub.isEmpty()){TextView s=tv(sub,13);s.setTextColor(MUTED);s.setPadding(0,dp(2),0,dp(8));box.addView(s);} return box; }
    TextView chip(String text, int bg, int fg) { TextView c=tv(text,12);c.setTextColor(fg);c.setGravity(Gravity.CENTER);c.setPadding(dp(10),0,dp(10),0);c.setBackground(round(bg,dp(14)));return c; }
    void addGap(int h){ content.addView(new Space(this),new LinearLayout.LayoutParams(1,dp(h))); }

    void showToday(){ selectedDate=todayKey(); clearScreen("Today");
        addDateNavigator(selectedDate);
        content.addView(buildProgressCard(selectedDate), new LinearLayout.LayoutParams(-1,dp(142)));
        addGap(10);
        Button add=button("＋  Add task"); add.setTextSize(15); add.setTextColor(Color.WHITE); add.setBackground(round(PURPLE,dp(16))); add.setOnClickListener(v->editTask(-1)); content.addView(add,new LinearLayout.LayoutParams(-1,dp(54))); addGap(10);
        TextView head=tv("Today's tasks",20); head.setTypeface(Typeface.DEFAULT_BOLD); content.addView(head); addGap(6);
        if(tasks.isEmpty()) { emptyState(); }
        for(Task t:tasks) addTodayTaskCard(t,selectedDate);
    }

    void addDateNavigator(String date){ LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);Button prev=button("‹");Button today=button("Today");Button next=button("›");TextView d=tv(nice(date),17);d.setGravity(Gravity.CENTER);prev.setOnClickListener(v->showAdjacentDay(-1));today.setOnClickListener(v->{selectedDate=todayKey();showToday();});next.setOnClickListener(v->showAdjacentDay(1));r.addView(prev,new LinearLayout.LayoutParams(dp(52),dp(48)));r.addView(d,new LinearLayout.LayoutParams(0,dp(48),1));r.addView(today,new LinearLayout.LayoutParams(dp(78),dp(48)));r.addView(next,new LinearLayout.LayoutParams(dp(52),dp(48)));content.addView(r);addGap(8); }
    void showAdjacentDay(int delta){try{Date dt=dayKey.parse(selectedDate);Calendar c=Calendar.getInstance();c.setTime(dt);c.add(Calendar.DAY_OF_YEAR,delta);String k=dayKey.format(c.getTime());if(k.compareTo(todayKey())>0)k=todayKey();selectedDate=k;showDay(k); }catch(Exception ignored){}}
    void showDay(String d){ currentTab=0; selectedDate=d; showToday(); }

    View buildProgressCard(String k){ LinearLayout card=new LinearLayout(this);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(16),dp(12),dp(16),dp(12));card.setBackground(round(Color.rgb(240,239,255),dp(22)));
        LinearLayout left=new LinearLayout(this);left.setOrientation(LinearLayout.VERTICAL);TextView small=tv("DAILY PROGRESS",11);small.setTextColor(PURPLE_DARK);small.setTypeface(Typeface.DEFAULT_BOLD);left.addView(small);TextView p=tv(pct(k)+"%",38);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextColor(PURPLE_DARK);left.addView(p);TextView sub=tv(yes(k)+" completed  •  "+no(k)+" not completed  •  "+pending(k)+" pending",12);sub.setTextColor(MUTED);left.addView(sub);
        card.addView(left,new LinearLayout.LayoutParams(0,-1,1)); LinearLayout donut=new LinearLayout(this);donut.setGravity(Gravity.CENTER);donut.addView(new CircularProgressView(this,pct(k)),new LinearLayout.LayoutParams(dp(86),dp(86)));card.addView(donut,new LinearLayout.LayoutParams(dp(98),-1)); return card; }

    void addTodayTaskCard(Task t,String d){ LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(14),dp(12),dp(14),dp(12)); card.setBackground(round(CARD,dp(20))); card.setElevation(dp(1));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL); TextView star=tv(t.fav?"★":"☆",24);star.setTextColor(t.fav?AMBER:Color.rgb(160,164,176));star.setGravity(Gravity.CENTER);star.setOnClickListener(v->{t.fav=!t.fav;db.saveTask(t);showToday();});top.addView(star,new LinearLayout.LayoutParams(dp(40),dp(40)));
        LinearLayout mid=new LinearLayout(this);mid.setOrientation(LinearLayout.VERTICAL);TextView name=tv(t.name,18);name.setTypeface(Typeface.DEFAULT_BOLD);name.setMaxLines(2);name.setEllipsize(TextUtils.TruncateAt.END);mid.addView(name);TextView meta=tv(t.category+"  •  "+t.priority+"  •  "+t.repeat+(t.reminder.isEmpty()?"":"  •  ⏰ "+t.reminder),12);meta.setTextColor(MUTED);meta.setMaxLines(1);meta.setEllipsize(TextUtils.TruncateAt.END);mid.addView(meta);top.addView(mid,new LinearLayout.LayoutParams(0,-2,1)); Button edit=button("⋮");edit.setTextSize(20);edit.setOnClickListener(v->editTask(tasks.indexOf(t)));top.addView(edit,new LinearLayout.LayoutParams(dp(44),dp(44)));card.addView(top);
        LinearLayout actions=new LinearLayout(this);actions.setPadding(dp(40),dp(8),0,0);int st=t.status(d); Button yes=button(st==1?"✓ Done":"Done"), no=button(st==2?"✕ Not done":"Not done"), pend=button(st==0?"— Pending":"Clear"); styleStatus(yes,st==1); styleStatus(no,st==2); stylePending(pend,st==0); yes.setOnClickListener(v->changeStatus(t,d,1)); no.setOnClickListener(v->changeStatus(t,d,2)); pend.setOnClickListener(v->changeStatus(t,d,0)); actions.addView(yes,new LinearLayout.LayoutParams(0,dp(44),1));actions.addView(no,new LinearLayout.LayoutParams(0,dp(44),1));actions.addView(pend,new LinearLayout.LayoutParams(0,dp(44),.82f));card.addView(actions);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(8));content.addView(card,cp);
    }
    void styleStatus(Button b,boolean on){b.setBackground(round(on?Color.rgb(220,252,231):Color.rgb(241,243,246),dp(14)));b.setTextColor(on?GREEN:TEXT);b.setTypeface(on?Typeface.DEFAULT_BOLD:Typeface.DEFAULT);}
    void styleStatus(Button b,int state){styleStatus(b,state==1);}
    void stylePending(Button b,boolean on){b.setBackground(round(on?Color.rgb(238,239,244):Color.rgb(241,243,246),dp(14)));b.setTextColor(MUTED);}
    void changeStatus(Task t,String d,int status){t.setStatus(d,status);db.setStatus(t.id,d,status);if(currentTab==0)showToday();else showMonth();}

    void showMonth(){ currentTab=1; int y=monthCursor.get(Calendar.YEAR),m=monthCursor.get(Calendar.MONTH); clearScreen("Month");
        LinearLayout monthbar=new LinearLayout(this);monthbar.setGravity(Gravity.CENTER_VERTICAL);Button prev=button("‹");Button home=button("Current");Button next=button("›");TextView mm=tv(new SimpleDateFormat("MMMM yyyy",Locale.US).format(monthCursor.getTime()),20);mm.setTypeface(Typeface.DEFAULT_BOLD);mm.setGravity(Gravity.CENTER);prev.setOnClickListener(v->{monthCursor.add(Calendar.MONTH,-1);showMonth();});home.setOnClickListener(v->{monthCursor=Calendar.getInstance();showMonth();});next.setOnClickListener(v->{monthCursor.add(Calendar.MONTH,1);showMonth();});monthbar.addView(prev,new LinearLayout.LayoutParams(dp(52),dp(48)));monthbar.addView(mm,new LinearLayout.LayoutParams(0,dp(48),1));monthbar.addView(home,new LinearLayout.LayoutParams(dp(82),dp(48)));monthbar.addView(next,new LinearLayout.LayoutParams(dp(52),dp(48)));content.addView(monthbar);addGap(8);
        LinearLayout hero=new LinearLayout(this);hero.setPadding(dp(16),dp(10),dp(16),dp(10));hero.setGravity(Gravity.CENTER_VERTICAL);hero.setBackground(round(Color.WHITE,dp(20)));TextView av=tv(monthAverage(y,m)+"%",32);av.setTypeface(Typeface.DEFAULT_BOLD);av.setTextColor(PURPLE_DARK);hero.addView(av,new LinearLayout.LayoutParams(dp(90),dp(72)));LinearLayout htxt=new LinearLayout(this);htxt.setOrientation(LinearLayout.VERTICAL);TextView h1=tv("Monthly average",17);h1.setTypeface(Typeface.DEFAULT_BOLD);htxt.addView(h1);TextView h2=tv("Future days are pending and excluded from the average.",12);h2.setTextColor(MUTED);htxt.addView(h2);hero.addView(htxt,new LinearLayout.LayoutParams(0,-2,1));content.addView(hero);addGap(12);
        TextView hint=tv("Swipe horizontally to view more dates  →",12);hint.setTextColor(MUTED);content.addView(hint);addGap(4);
        int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH); HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setFillViewport(false);hsv.setHorizontalScrollBarEnabled(true); LinearLayout matrix=new LinearLayout(this);matrix.setOrientation(LinearLayout.VERTICAL); LinearLayout header=new LinearLayout(this); header.addView(cell("TASK",dp(180),true),cellParams(dp(180),dp(58))); for(int d=1;d<=days;d++){String lab=d+"\n"+new SimpleDateFormat("EEE",Locale.US).format(new GregorianCalendar(y,m,d).getTime()).substring(0,3);Button b=button(lab);b.setTextSize(12);b.setPadding(0,0,0,0);final String k=keyFor(y,m,d);b.setOnClickListener(v->showDay(k));header.addView(b,cellParams(dp(76),dp(58)));}matrix.addView(header);
        if(tasks.isEmpty()){TextView e=tv("No tasks yet. Use + to create your first task.",16);e.setTextColor(MUTED);e.setPadding(dp(12),dp(20),dp(12),dp(20));matrix.addView(e);}
        for(Task t:tasks){LinearLayout row=new LinearLayout(this);TextView n=cell(t.name,dp(180),true);n.setTextSize(15);n.setPadding(dp(12),0,dp(10),0);n.setMaxLines(2);n.setEllipsize(TextUtils.TruncateAt.END);n.setOnClickListener(v->showTaskMonth(t));row.addView(n,cellParams(dp(180),dp(64)));for(int d=1;d<=days;d++){String k=keyFor(y,m,d);Button b=button(mark(t.status(k)));b.setTextSize(22);styleMatrixCell(b,t.status(k),isFuture(k));b.setOnClickListener(v->chooseStatus(t,k));row.addView(b,cellParams(dp(76),dp(64)));}matrix.addView(row);}hsv.addView(matrix);content.addView(hsv,new LinearLayout.LayoutParams(-1,-2));addGap(16);
        content.addView(section("Daily completion","Completed tasks ÷ total tasks for each past/current day."));content.addView(graphScroll(new MonthChart(this,y,m),Math.max(dp(980),days*dp(44)),dp(320)),new LinearLayout.LayoutParams(-1,dp(340)));addGap(10);
        content.addView(section("Task performance","Completed days out of the full selected month."));content.addView(graphScroll(new TaskComparisonChart(this,y,m),Math.max(dp(860),tasks.size()*dp(150)),dp(330)),new LinearLayout.LayoutParams(-1,dp(350)));addGap(8);
        Button open=button("Open today →");open.setTextSize(15);open.setTextColor(Color.WHITE);open.setBackground(round(PURPLE,dp(16)));open.setOnClickListener(v->{selectedDate=todayKey();showToday();});content.addView(open,new LinearLayout.LayoutParams(-1,dp(52)));
    }
    TextView cell(String s,int w,boolean bold){TextView t=tv(s,13);t.setGravity(Gravity.CENTER_VERTICAL);t.setBackgroundColor(Color.rgb(236,237,242));if(bold)t.setTypeface(Typeface.DEFAULT_BOLD);t.setMinWidth(w);t.setMaxWidth(w);return t;}
    LinearLayout.LayoutParams cellParams(int w,int h){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(w,h);lp.setMargins(dp(1),0,dp(1),dp(1));return lp;}
    String mark(int s){return s==1?"✓":s==2?"✕":"—";}
    void styleMatrixCell(Button b,int state,boolean future){if(future){b.setTextColor(Color.rgb(170,173,182));b.setBackground(round(Color.rgb(245,246,248),dp(12)));return;}if(state==1){b.setTextColor(GREEN);b.setBackground(round(Color.rgb(220,252,231),dp(12)));}else if(state==2){b.setTextColor(RED);b.setBackground(round(Color.rgb(254,226,226),dp(12)));}else{b.setTextColor(MUTED);b.setBackground(round(Color.rgb(242,243,246),dp(12)));}}
    void chooseStatus(Task t,String k){ if(isFuture(k)){Toast.makeText(this,"Future dates stay pending.",Toast.LENGTH_SHORT).show();return;} String[] items={"✓  Completed","✕  Not completed","—  Pending / clear"};new AlertDialog.Builder(this).setTitle(t.name+" • "+nice(k)).setItems(items,(d,w)->changeStatus(t,k,w==0?1:w==1?2:0)).show(); }
    void showTaskMonth(Task t){ int y=monthCursor.get(Calendar.YEAR),m=monthCursor.get(Calendar.MONTH); clearScreen(t.name);TextView h=tv(new SimpleDateFormat("MMMM yyyy",Locale.US).format(monthCursor.getTime()),18);h.setTypeface(Typeface.DEFAULT_BOLD);content.addView(h);int done=completedDays(t,y,m);int fullDays=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH);TextView p=tv(taskPct(t,y,m)+"%",34);p.setTextColor(PURPLE_DARK);p.setTypeface(Typeface.DEFAULT_BOLD);p.setPadding(0,dp(12),0,dp(4));content.addView(p);content.addView(tv(done+" completed days out of "+fullDays+" days in the month",13));addGap(12);for(int d=1;d<=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH);d++){String k=keyFor(y,m,d);if(isFuture(k))continue;TextView r=tv(d+"  "+mark(t.status(k))+"    day completion "+pct(k)+"%",15);r.setPadding(dp(12),dp(12),dp(12),dp(12));r.setBackground(round(Color.WHITE,dp(12)));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(46));rp.setMargins(0,0,0,dp(4));content.addView(r,rp);} }

    void showStats(){ currentTab=2;int y=monthCursor.get(Calendar.YEAR),m=monthCursor.get(Calendar.MONTH);clearScreen("Stats");
        LinearLayout cards=new LinearLayout(this);cards.setGravity(Gravity.CENTER);cards.setPadding(0,0,0,dp(8)); addStatCard(cards,"MONTH",monthAverage(y,m)+"%",PURPLE_DARK); addStatCard(cards,"DONE",String.valueOf(sumDone(y,m)),GREEN); addStatCard(cards,"TASKS",String.valueOf(tasks.size()),TEXT); content.addView(cards,new LinearLayout.LayoutParams(-1,dp(100)));
        content.addView(section("Daily completion — "+new SimpleDateFormat("MMMM yyyy",Locale.US).format(monthCursor.getTime()),"Tap a date in Month to change status."));content.addView(graphScroll(new MonthChart(this,y,m),Math.max(dp(980),new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH)*dp(44)),dp(300)),new LinearLayout.LayoutParams(-1,dp(320)));addGap(10);
        content.addView(section("Task performance","Completed days out of the full selected month."));content.addView(graphScroll(new TaskComparisonChart(this,y,m),Math.max(dp(860),tasks.size()*dp(150)),dp(320)),new LinearLayout.LayoutParams(-1,dp(340)));addGap(8);
        content.addView(section("Yearly monthly averages — "+y,"Future months remain at 0 until they have elapsed days."));content.addView(new YearChart(this,y),new LinearLayout.LayoutParams(-1,dp(250))); }
    int sumDone(int y,int m){int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH),s=0;for(int d=1;d<=days;d++)if(!isFuture(keyFor(y,m,d)))s+=yes(keyFor(y,m,d));return s;}
    void addStatCard(LinearLayout p,String label,String value,int c){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER);card.setBackground(round(Color.WHITE,dp(18)));TextView a=tv(label,10);a.setTextColor(MUTED);a.setTypeface(Typeface.DEFAULT_BOLD);card.addView(a);TextView b=tv(value,22);b.setTextColor(c);b.setTypeface(Typeface.DEFAULT_BOLD);card.addView(b);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.setMargins(dp(3),0,dp(3),0);p.addView(card,lp);}

    void showTasks(){currentTab=3;clearScreen("Tasks"); LinearLayout searchRow=new LinearLayout(this);EditText search=new EditText(this);search.setHint("Search tasks");search.setSingleLine(true);search.setTextSize(15);search.setPadding(dp(12),0,dp(12),0);search.setBackground(round(Color.WHITE,dp(16)));searchRow.addView(search,new LinearLayout.LayoutParams(0,dp(50),1));Button add=button("＋");add.setTextSize(21);add.setTextColor(Color.WHITE);add.setBackground(round(PURPLE,dp(16)));add.setOnClickListener(v->editTask(-1));searchRow.addView(add,new LinearLayout.LayoutParams(dp(54),dp(50)));content.addView(searchRow);addGap(8);
        LinearLayout filters=new LinearLayout(this);String[] fs={"All","Favourites","High"};for(String f:fs){Button b=button(f);b.setTextSize(12);b.setOnClickListener(v->{taskFilter=f;showTasks();});b.setBackground(round(taskFilter.equals(f)?Color.rgb(232,231,255):Color.WHITE,dp(14)));b.setTextColor(taskFilter.equals(f)?PURPLE_DARK:MUTED);filters.addView(b,new LinearLayout.LayoutParams(0,dp(44),1));}content.addView(filters);addGap(8);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);
        final String[] query={""};search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){query[0]=s.toString();renderTaskList(list,query[0]);}public void afterTextChanged(android.text.Editable e){}});renderTaskList(list,"");
    }
    void renderTaskList(LinearLayout list,String q){list.removeAllViews();for(Task t:tasks){boolean match=t.name.toLowerCase(Locale.US).contains(q.toLowerCase(Locale.US))||t.category.toLowerCase(Locale.US).contains(q.toLowerCase(Locale.US));boolean filter=(taskFilter.equals("All")||(taskFilter.equals("Favourites")&&t.fav)||(taskFilter.equals("High")&&t.priority.equals("High")));if(!match||!filter)continue;LinearLayout c=new LinearLayout(this);c.setGravity(Gravity.CENTER_VERTICAL);c.setPadding(dp(12),dp(10),dp(8),dp(10));c.setBackground(round(Color.WHITE,dp(18)));TextView s=tv(t.fav?"★":"☆",23);s.setTextColor(t.fav?AMBER:Color.LTGRAY);s.setOnClickListener(v->{t.fav=!t.fav;db.saveTask(t);showTasks();});c.addView(s,new LinearLayout.LayoutParams(dp(42),dp(54)));LinearLayout mid=new LinearLayout(this);mid.setOrientation(LinearLayout.VERTICAL);TextView n=tv(t.name,17);n.setTypeface(Typeface.DEFAULT_BOLD);mid.addView(n);TextView m=tv(t.category+"  •  "+t.priority+"  •  "+t.repeat,12);m.setTextColor(MUTED);mid.addView(m);c.addView(mid,new LinearLayout.LayoutParams(0,-2,1));Button e=button("EDIT");e.setOnClickListener(v->editTask(tasks.indexOf(t)));c.addView(e,new LinearLayout.LayoutParams(dp(64),dp(44)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(7));list.addView(c,lp);}if(list.getChildCount()==0){TextView e=tv("No matching tasks.",15);e.setTextColor(MUTED);e.setGravity(Gravity.CENTER);e.setPadding(0,dp(24),0,dp(24));list.addView(e);}}

    void showMore(){currentTab=4;clearScreen("More"); addMoreButton("Export backup","Save all tasks and history to a file.",v->exportBackup());addMoreButton("Import backup","Replace local data from a Task Tracker backup.",v->importBackup());addMoreButton("Reminders","Daily notification times are stored per task.",v->showReminderInfo());addMoreButton("Cloud / Login","Optional cloud sync is not enabled in the offline build.",v->cloudInfo());addMoreButton("About V19","Major UI redesign + SQLite local database + improved navigation.",v->new AlertDialog.Builder(this).setTitle("Task Tracker V19").setMessage("V19 is designed as a stable foundation for future features. Your existing V18-style data is migrated on first launch when available.").setPositiveButton("OK",null).show()); }
    void addMoreButton(String h,String sub,View.OnClickListener l){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(14),dp(12),dp(10),dp(10));c.setBackground(round(Color.WHITE,dp(18)));TextView a=tv(h,17);a.setTypeface(Typeface.DEFAULT_BOLD);c.addView(a);TextView b=tv(sub,12);b.setTextColor(MUTED);c.addView(b);c.setOnClickListener(l);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(72));lp.setMargins(0,0,0,dp(8));content.addView(c,lp);}
    void showReminderInfo(){new AlertDialog.Builder(this).setTitle("Reminders").setMessage("Each task can have one daily reminder time. Android may adjust inexact alarm timing to save battery.").setPositiveButton("OK",null).show();}
    void cloudInfo(){new AlertDialog.Builder(this).setTitle("Cloud / Login").setMessage("V19 remains offline-first. A real cloud account requires a backend configuration; the app does not use a fake login. Use Export backup to keep a copy in Drive or another storage service.").setPositiveButton("OK",null).show();}

    void editTask(int ix){LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.setPadding(dp(4),0,dp(4),0);EditText n=new EditText(this);n.setHint("Task name");EditText c=new EditText(this);c.setHint("Category");EditText note=new EditText(this);note.setHint("Notes");note.setMinLines(2);note.setGravity(Gravity.TOP);Spinner p=new Spinner(this);p.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"High","Medium","Low"}));Spinner r=new Spinner(this);r.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Once","Daily","Weekly","Monthly"}));Button reminder=button("⏰ Reminder: Off");final String[] rem={ix>=0?tasks.get(ix).reminder:""};reminder.setOnClickListener(v->pickReminder(reminder,rem));f.addView(n);f.addView(c);f.addView(p);f.addView(r);f.addView(reminder,new LinearLayout.LayoutParams(-1,dp(52)));f.addView(note);if(ix>=0){Task t=tasks.get(ix);n.setText(t.name);c.setText(t.category);note.setText(t.note);String[] ps={"High","Medium","Low"},rs={"Once","Daily","Weekly","Monthly"};for(int i=0;i<ps.length;i++)if(ps[i].equals(t.priority))p.setSelection(i);for(int i=0;i<rs.length;i++)if(rs[i].equals(t.repeat))r.setSelection(i);if(!rem[0].isEmpty())reminder.setText("⏰ Reminder: "+rem[0]);}
        AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle(ix<0?"Add task":"Edit task").setView(f).setPositiveButton("SAVE",(d,w)->{String nn=n.getText().toString().trim();if(nn.isEmpty())return;String cc=c.getText().toString().trim();if(cc.isEmpty())cc="General";Task t;if(ix<0){t=new Task(UUID.randomUUID().toString(),nn,cc,p.getSelectedItem().toString(),r.getSelectedItem().toString(),note.getText().toString().trim(),rem[0]);tasks.add(t);}else{t=tasks.get(ix);t.name=nn;t.category=cc;t.priority=p.getSelectedItem().toString();t.repeat=r.getSelectedItem().toString();t.note=note.getText().toString().trim();t.reminder=rem[0];}db.saveTask(t);scheduleReminder(t);if(currentTab==0)showToday();else if(currentTab==3)showTasks();else showMonth();}).setNegativeButton("CANCEL",null);
        if(ix>=0)b.setNeutralButton("DELETE",(d,w)->{cancelReminder(tasks.get(ix));db.deleteTask(tasks.get(ix).id);tasks.remove(ix);if(currentTab==3)showTasks();else showMonth();});b.show(); }
    void pickReminder(Button b,String[] val){Calendar now=Calendar.getInstance();TimePickerDialog d=new TimePickerDialog(this,(v,h,m)->{val[0]=String.format(Locale.US,"%02d:%02d",h,m);b.setText("⏰ Reminder: "+val[0]);},now.get(Calendar.HOUR_OF_DAY),now.get(Calendar.MINUTE),true);d.setTitle("Daily reminder time");d.setButton(DialogInterface.BUTTON_NEGATIVE,"OFF",(x,w)->{val[0]="";b.setText("⏰ Reminder: Off");});d.show();}

    void exportBackup(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/plain");i.putExtra(Intent.EXTRA_TITLE,"TaskTracker_V19_Backup.txt");startActivityForResult(i,77);}
    void importBackup(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("text/plain");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,78);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;try{if(req==77){OutputStream out=getContentResolver().openOutputStream(data.getData());out.write(exportText().getBytes("UTF-8"));out.close();Toast.makeText(this,"Backup exported",Toast.LENGTH_SHORT).show();}else if(req==78){BufferedReader br=new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(data.getData()),"UTF-8"));StringBuilder sb=new StringBuilder();String l;while((l=br.readLine())!=null)sb.append(l).append('\n');br.close();importText(sb.toString());Toast.makeText(this,"Backup restored",Toast.LENGTH_SHORT).show();showMonth();}}catch(Exception e){Toast.makeText(this,"Backup operation failed",Toast.LENGTH_SHORT).show();}}
    String exportText(){StringBuilder o=new StringBuilder("TASKTRACKER_V19\n");for(Task t:tasks){o.append(clean(t.id)).append('|').append(clean(t.name)).append('|').append(clean(t.category)).append('|').append(clean(t.priority)).append('|').append(clean(t.repeat)).append('|').append(clean(t.note)).append('|').append(t.fav?1:0).append('|').append(clean(t.reminder)).append('|');boolean first=true;for(Map.Entry<String,Integer> e:t.history.entrySet()){if(!first)o.append(',');first=false;o.append(e.getKey()).append('=').append(e.getValue());}o.append('\n');}return o.toString();}
    String clean(String s){if(s==null)return "";return s.replace("\\","/").replace("|","/").replace("\n"," ").replace(",",";");}
    void importText(String data){db.clearAll();tasks.clear();for(String line:data.split("\\n")){if(line.startsWith("TASKTRACKER_V19")||line.trim().isEmpty())continue;String[] p=line.split("\\|",-1);if(p.length<9)continue;Task t=new Task(p[0],p[1],p[2],p[3],p[4],p[5],p[7]);t.fav="1".equals(p[6]);if(!p[8].isEmpty())for(String e:p[8].split(",")){String[] q=e.split("=");if(q.length==2)try{t.history.put(q[0],Integer.parseInt(q[1]));}catch(Exception ignored){}}db.saveTask(t);tasks.add(t);}scheduleAllReminders();}

    void migrateLegacyIfNeeded(){if(db.countTasks()>0)return;String data=getSharedPreferences(LEGACY_PREF,MODE_PRIVATE).getString("data","");if(data.isEmpty()){data=getSharedPreferences(OLD_PREF_V3,MODE_PRIVATE).getString("data","");}if(data.isEmpty()){data=getSharedPreferences(OLD_PREF_V2,MODE_PRIVATE).getString("data","");}if(data.isEmpty()){data=getSharedPreferences(OLD_PREF_V1,MODE_PRIVATE).getString("data","");}if(data.isEmpty())return;try{parseLegacyIntoDb(data);}catch(Exception ignored){}}
    void parseLegacyIntoDb(String data){for(String line:data.split("\\n")){String[] p=line.split("\\|",-1);if(p.length<8)continue;if(p.length>=9){String reminder=p[7];String hist=p[8];Task t=new Task(p[0],p[1],p[2],p[3],p[4],p[5],reminder);t.fav="1".equals(p[6]);if(!hist.isEmpty())for(String e:hist.split(",")){String[] q=e.split("=");if(q.length==2)try{t.history.put(q[0],Integer.parseInt(q[1]));}catch(Exception ignored){}}db.saveTask(t);}else{Task t=new Task(p[0],p[1],p[2],p[3],p[4],p[5],"");t.fav="1".equals(p[7]);if("1".equals(p[6]))t.history.put(todayKey(),1);db.saveTask(t);}}}

    void createNotificationChannel(){if(Build.VERSION.SDK_INT>=26){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);NotificationChannel ch=new NotificationChannel("task_reminders","Task reminders",NotificationManager.IMPORTANCE_DEFAULT);ch.setDescription("Task Tracker daily reminders");nm.createNotificationChannel(ch);}}
    int reminderId(Task t){return Math.abs(t.id.hashCode());}
    void scheduleAllReminders(){for(Task t:tasks)scheduleReminder(t);}
    void cancelReminder(Task t){AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);Intent in=new Intent(this,ReminderReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(this,reminderId(t),in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);am.cancel(pi);}
    void scheduleReminder(Task t){cancelReminder(t);if(t.reminder==null||t.reminder.isEmpty())return;try{String[] q=t.reminder.split(":");Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,Integer.parseInt(q[0]));c.set(Calendar.MINUTE,Integer.parseInt(q[1]));c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);if(c.before(Calendar.getInstance()))c.add(Calendar.DAY_OF_YEAR,1);Intent in=new Intent(this,ReminderReceiver.class);in.putExtra("taskName",t.name);in.putExtra("taskId",t.id);PendingIntent pi=PendingIntent.getBroadcast(this,reminderId(t),in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);am.setInexactRepeating(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);}catch(Exception ignored){}}

    HorizontalScrollView graphScroll(View v,int width,int height){HorizontalScrollView h=new HorizontalScrollView(this);h.setFillViewport(false);h.setHorizontalScrollBarEnabled(true);FrameLayout f=new FrameLayout(this);f.addView(v,new FrameLayout.LayoutParams(width,height));h.addView(f,new HorizontalScrollView.LayoutParams(width,height));return h;}

    class CircularProgressView extends View {Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);int value;CircularProgressView(Context c,int v){super(c);value=v;}protected void onDraw(Canvas c){super.onDraw(c);float cx=getWidth()/2f,cy=getHeight()/2f,rad=Math.min(getWidth(),getHeight())/2f-9;p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(10);p.setStrokeCap(Paint.Cap.ROUND);p.setColor(Color.rgb(221,221,237));c.drawCircle(cx,cy,rad,p);p.setColor(PURPLE);c.drawArc(cx-rad,cy-rad,cx+rad,cy+rad,-90,360*value/100f,false,p);p.setStyle(Paint.Style.FILL);p.setColor(PURPLE_DARK);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(20);c.drawText(value+"%",cx,cy+7,p);p.setTextAlign(Paint.Align.LEFT);}}

    class MonthChart extends View {Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);int y,m;MonthChart(Context c,int yy,int mm){super(c);y=yy;m=mm;setLayerType(View.LAYER_TYPE_HARDWARE,null);}protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(Color.WHITE);int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH);float l=54,t=34,r=getWidth()-22,b=getHeight()-46;for(int q=0;q<=4;q++){float yy=b-(b-t)*q/4f;p.setColor(Color.rgb(229,231,235));p.setStrokeWidth(1);c.drawLine(l,yy,r,yy,p);p.setColor(MUTED);p.setTextSize(10);c.drawText((q*25)+"%",8,yy+4,p);}float slot=(r-l)/Math.max(1,days);ArrayList<Float> xs=new ArrayList<>(),ys=new ArrayList<>();boolean started=false;p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setStrokeCap(Paint.Cap.ROUND);p.setColor(PURPLE);Path path=new Path();for(int d=1;d<=days;d++){String k=keyFor(y,m,d);float x=l+(d-.5f)*slot;float yy=b-(b-t)*pct(k)/100f;xs.add(x);ys.add(yy);if(isFuture(k))continue;if(!started){path.moveTo(x,yy);started=true;}else{float px=xs.get(d-2),py=ys.get(d-2),mid=(px+x)/2f;path.cubicTo(mid,py,mid,yy,x,yy);}}if(started)c.drawPath(path,p);p.setStyle(Paint.Style.FILL);for(int d=1;d<=days;d++){String k=keyFor(y,m,d);if(isFuture(k))continue;int v=pct(k);float x=xs.get(d-1),yy=ys.get(d-1);p.setColor(v>=75?GREEN:v>=40?AMBER:v>0?RED:Color.rgb(150,154,166));c.drawCircle(x,yy,5,p);p.setColor(TEXT);p.setTextSize(9);String label=v+"%";float w=p.measureText(label);c.drawText(label,x-w/2,Math.max(t+12,yy-9),p);p.setTextSize(9);c.drawText(String.valueOf(d),x-p.measureText(String.valueOf(d))/2,b+18,p);}p.setTextSize(10);p.setColor(MUTED);c.drawText("Daily completion • completed ÷ total",l,16,p);}}

    class TaskComparisonChart extends View {Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);int y,m;int[] colors={Color.rgb(59,130,246),Color.rgb(16,185,129),Color.rgb(245,158,11),Color.rgb(239,68,68),Color.rgb(168,85,247),Color.rgb(14,165,233),Color.rgb(236,72,153)};TaskComparisonChart(Context c,int yy,int mm){super(c);y=yy;m=mm;setLayerType(View.LAYER_TYPE_HARDWARE,null);}protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(Color.WHITE);float l=48,t=30,r=getWidth()-18,b=getHeight()-62;for(int q=0;q<=4;q++){float yy=b-(b-t)*q/4f;p.setColor(Color.rgb(229,231,235));c.drawLine(l,yy,r,yy,p);p.setColor(MUTED);p.setTextSize(10);c.drawText((q*25)+"%",6,yy+4,p);}if(tasks.isEmpty()){p.setColor(MUTED);p.setTextSize(14);c.drawText("Add tasks to see performance.",l,t+24,p);return;}float slot=(r-l)/Math.max(1,tasks.size());float bw=Math.min(dp(82),slot*.58f);for(int i=0;i<tasks.size();i++){Task task=tasks.get(i);int done=completedDays(task,y,m);int v=taskPct(task,y,m);float x=l+i*slot+(slot-bw)/2f;float h=(b-t)*v/100f;p.setColor(colors[i%colors.length]);c.drawRoundRect(x,b-h,x+bw,b,14,14,p);p.setColor(TEXT);p.setTextSize(10);String val=done+"d  "+v+"%";float vw=p.measureText(val);c.drawText(val,x+bw/2-vw/2,Math.max(t+12,b-h-8),p);String nm=task.name;nm=nm.length()>11?nm.substring(0,10)+"…":nm;p.setTextSize(9);float nw=p.measureText(nm);c.drawText(nm,x+bw/2-nw/2,b+18,p);}}}

    class YearChart extends View {Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);int y;YearChart(Context c,int yy){super(c);y=yy;}protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(Color.WHITE);float l=32,t=18,r=getWidth()-8,b=getHeight()-36;for(int q=0;q<=4;q++){float yy=b-(b-t)*q/4f;p.setColor(Color.rgb(229,231,235));c.drawLine(l,yy,r,yy,p);p.setColor(MUTED);p.setTextSize(9);c.drawText((q*25)+"%",4,yy+3,p);}float slot=(r-l)/12f,bw=slot*.56f;for(int m=0;m<12;m++){int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH),s=0,n=0;for(int d=1;d<=days;d++){String k=keyFor(y,m,d);if(total(k)>0){s+=pct(k);n++;}}int v=n==0?0:Math.round((float)s/n);float x=l+m*slot+(slot-bw)/2,h=(b-t)*v/100f;p.setColor(v==0?Color.rgb(229,231,235):PURPLE);c.drawRoundRect(x,b-h,x+bw,b,8,8,p);p.setColor(MUTED);p.setTextSize(8);String mon=new SimpleDateFormat("MMM",Locale.US).format(new GregorianCalendar(y,m,1).getTime());c.drawText(mon,x+bw/2-p.measureText(mon)/2,b+15,p);if(v>0){p.setTextSize(8);c.drawText(String.valueOf(v),x+bw/2-p.measureText(String.valueOf(v))/2,b-h-4,p);}}}}

    void emptyState(){LinearLayout e=new LinearLayout(this);e.setOrientation(LinearLayout.VERTICAL);e.setGravity(Gravity.CENTER);e.setPadding(dp(20),dp(30),dp(20),dp(30));TextView a=tv("No tasks yet",20);a.setTypeface(Typeface.DEFAULT_BOLD);e.addView(a);TextView b=tv("Create a task and start building your daily history.",13);b.setTextColor(MUTED);e.addView(b);content.addView(e,new LinearLayout.LayoutParams(-1,dp(130)));}
}

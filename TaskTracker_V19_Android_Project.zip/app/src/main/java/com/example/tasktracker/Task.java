package com.example.tasktracker;

import java.util.HashMap;

public class Task {
    public String id;
    public String name;
    public String category;
    public String priority;
    public String repeat;
    public String note;
    public String reminder;
    public boolean fav;
    public HashMap<String,Integer> history = new HashMap<>();

    public Task(String id, String name, String category, String priority, String repeat, String note, String reminder) {
        this.id = id;
        this.name = name;
        this.category = category == null || category.isEmpty() ? "General" : category;
        this.priority = priority == null || priority.isEmpty() ? "Medium" : priority;
        this.repeat = repeat == null || repeat.isEmpty() ? "Daily" : repeat;
        this.note = note == null ? "" : note;
        this.reminder = reminder == null ? "" : reminder;
    }

    public int status(String date) {
        Integer v = history.get(date);
        return v == null ? 0 : v;
    }

    public void setStatus(String date, int status) {
        if (status == 0) history.remove(date);
        else history.put(date, status);
    }
}

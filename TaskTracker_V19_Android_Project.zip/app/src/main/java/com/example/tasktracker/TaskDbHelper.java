package com.example.tasktracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.Map;

public class TaskDbHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "task_tracker_v19.db";
    private static final int DB_VERSION = 1;

    public TaskDbHelper(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE tasks (id TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT, priority TEXT, repeat_rule TEXT, note TEXT, fav INTEGER NOT NULL DEFAULT 0, reminder TEXT)");
        db.execSQL("CREATE TABLE status (task_id TEXT NOT NULL, date TEXT NOT NULL, state INTEGER NOT NULL, PRIMARY KEY(task_id,date), FOREIGN KEY(task_id) REFERENCES tasks(id) ON DELETE CASCADE)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    public int countTasks() {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM tasks", null);
        try { return c.moveToFirst() ? c.getInt(0) : 0; } finally { c.close(); }
    }

    public ArrayList<Task> loadTasks() {
        ArrayList<Task> out = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query("tasks", null, null, null, null, null, "name COLLATE NOCASE ASC");
        try {
            while (c.moveToNext()) {
                Task t = new Task(c.getString(c.getColumnIndexOrThrow("id")),
                        c.getString(c.getColumnIndexOrThrow("name")),
                        c.getString(c.getColumnIndexOrThrow("category")),
                        c.getString(c.getColumnIndexOrThrow("priority")),
                        c.getString(c.getColumnIndexOrThrow("repeat_rule")),
                        c.getString(c.getColumnIndexOrThrow("note")),
                        c.getString(c.getColumnIndexOrThrow("reminder")));
                t.fav = c.getInt(c.getColumnIndexOrThrow("fav")) != 0;
                Cursor s = db.query("status", new String[]{"date","state"}, "task_id=?", new String[]{t.id}, null, null, "date ASC");
                try { while (s.moveToNext()) t.history.put(s.getString(0), s.getInt(1)); }
                finally { s.close(); }
                out.add(t);
            }
        } finally { c.close(); }
        return out;
    }

    public void saveTask(Task t) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues v = new ContentValues();
            v.put("id", t.id); v.put("name", t.name); v.put("category", t.category); v.put("priority", t.priority);
            v.put("repeat_rule", t.repeat); v.put("note", t.note); v.put("fav", t.fav ? 1 : 0); v.put("reminder", t.reminder);
            db.insertWithOnConflict("tasks", null, v, SQLiteDatabase.CONFLICT_REPLACE);
            db.delete("status", "task_id=?", new String[]{t.id});
            for (Map.Entry<String,Integer> e : t.history.entrySet()) {
                ContentValues s = new ContentValues(); s.put("task_id", t.id); s.put("date", e.getKey()); s.put("state", e.getValue());
                db.insertWithOnConflict("status", null, s, SQLiteDatabase.CONFLICT_REPLACE);
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public void setStatus(String taskId, String date, int state) {
        SQLiteDatabase db = getWritableDatabase();
        if (state == 0) db.delete("status", "task_id=? AND date=?", new String[]{taskId, date});
        else { ContentValues v = new ContentValues(); v.put("task_id", taskId); v.put("date", date); v.put("state", state); db.insertWithOnConflict("status", null, v, SQLiteDatabase.CONFLICT_REPLACE); }
    }

    public void deleteTask(String id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("status", "task_id=?", new String[]{id});
        db.delete("tasks", "id=?", new String[]{id});
    }

    public void clearAll() { getWritableDatabase().delete("status", null, null); getWritableDatabase().delete("tasks", null, null); }
}

package com.example.tasktracker;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    static final String PREF = "task_tracker_v4";
    static final String OLD_PREF_V3 = "task_tracker_v3";
    static final String OLD_PREF_V2 = "v2";
    static final String OLD_PREF_V1 = "tasks";
    static final int PURPLE = Color.rgb(79,70,229);

    LinearLayout content;
    TextView title, summary;
    ArrayList<Task> tasks = new ArrayList<>();
    SharedPreferences sp;
    Calendar monthCursor = Calendar.getInstance();
    String selectedDate;
    final SimpleDateFormat dayKey = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
    final SimpleDateFormat niceDate = new SimpleDateFormat("EEE, dd MMM yyyy", Locale.US);

    static class Task {
        String id, name, category, priority, repeat, note;
        boolean fav;
        HashMap<String,Integer> history = new HashMap<>(); // 0=pending/unknown, 1=yes, 2=no
        Task(String id,String name,String category,String priority,String repeat,String note){
            this.id=id; this.name=name; this.category=category; this.priority=priority;
            this.repeat=repeat; this.note=note;
        }
        int status(String date){
            Integer v=history.get(date);
            return v==null?0:v;
        }
        void setStatus(String date,int s){ history.put(date,s); }
    }

    public void onCreate(Bundle b) {
        super.onCreate(b);
        sp=getSharedPreferences(PREF,MODE_PRIVATE);
        selectedDate=todayKey();
        load();
        if (Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 10);
        buildShell();
        showToday();
    }

    String todayKey(){ return dayKey.format(new Date()); }

    TextView text(String s,int size) {
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(25,25,35));
        t.setPadding(14,9,14,9);
        return t;
    }

    Button navButton(String label) {
        Button b=new Button(this); b.setText(label); b.setTextSize(10); return b;
    }

    Button action(String s) {
        Button b=new Button(this); b.setText(s); return b;
    }

    void buildShell() {
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(10,12,10,5);

        title=text("Task Tracker V4",27); title.setTypeface(null,1); root.addView(title);
        summary=text("",15); root.addView(summary);

        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll=new ScrollView(this); scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav=new LinearLayout(this); nav.setBackgroundColor(Color.rgb(245,245,248));
        String[] labels={"Today","Calendar","Stats","Tasks","More"};
        for(String label:labels){
            Button b=navButton(label);
            b.setOnClickListener(v->{
                if(label.equals("Today")) showToday();
                else if(label.equals("Calendar")) showCalendar();
                else if(label.equals("Stats")) showStats();
                else if(label.equals("Tasks")) showTasks();
                else showMore();
            });
            nav.addView(b,new LinearLayout.LayoutParams(0,62,1));
        }
        root.addView(nav); setContentView(root);
    }

    void clear(String heading){ title.setText(heading); content.removeAllViews(); }

    int monthCompleted(int year,int month){
        int total=0, done=0;
        Calendar c=new GregorianCalendar(year,month,1);
        int days=c.getActualMaximum(Calendar.DAY_OF_MONTH);
        for(int d=1;d<=days;d++){
            String key=keyFor(year,month,d);
            for(Task t:tasks){
                if(isExpected(t,key)){ total++; if(t.status(key)==1) done++; }
            }
        }
        return total==0?0:(done*100/total);
    }

    boolean isExpected(Task t,String key){
        if(t.repeat.equals("Daily")) return true;
        if(t.repeat.equals("Weekly")){
            try{ Date d=dayKey.parse(key); Calendar c=Calendar.getInstance(); c.setTime(d); return true; }catch(Exception e){return true;}
        }
        if(t.repeat.equals("Monthly")) return true;
        return key.equals(todayKey()) || t.history.containsKey(key);
    }

    int statusFor(Task t,String key){ return t.status(key); }

    void setStatus(Task t,String date,int status){ t.setStatus(date,status); save(); }

    int dayTotal(String date){ int n=0; for(Task t:tasks) if(isExpected(t,date)) n++; return n; }
    int dayDone(String date){ int n=0; for(Task t:tasks) if(isExpected(t,date)&&t.status(date)==1)n++; return n; }
    int dayNo(String date){ int n=0; for(Task t:tasks) if(isExpected(t,date)&&t.status(date)==2)n++; return n; }
    int dayPercent(String date){ int n=dayTotal(date); return n==0?0:dayDone(date)*100/n; }

    void updateSummaryFor(String date){
        int total=dayTotal(date), yes=dayDone(date), no=dayNo(date);
        String label=date.equals(todayKey())?"Today":niceDateFor(date);
        summary.setText(label+"  •  "+yes+" yes / "+no+" no / "+Math.max(0,total-yes-no)+" pending  •  "+(total==0?0:yes*100/total)+"%");
    }

    String niceDateFor(String key){
        try{return niceDate.format(dayKey.parse(key));}catch(Exception e){return key;}
    }

    void showToday(){ showDay(todayKey(),"Today"); }

    void showDay(String date,String heading){
        selectedDate=date; clear(heading); updateSummaryFor(date);
        Button add=action("+ ADD TASK"); add.setOnClickListener(v->editTask(-1)); content.addView(add);
        if(tasks.isEmpty()){ content.addView(text("No tasks yet. Add your first task.",17)); return; }
        for(int i=0;i<tasks.size();i++) addTaskCard(i,date);
        content.addView(text("\nDay completion",18));
        content.addView(new ProgressView(this,dayPercent(date)));
    }

    void addTaskCard(int ix,String date){
        Task t=tasks.get(ix);
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(3,7,3,7);
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView name=text(t.name,17); name.setTypeface(null,1);
        row.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        int s=t.status(date);
        Button yes=action(s==1?"YES ✓":"YES"); yes.setOnClickListener(v->{setStatus(t,date,1); showDay(date,date.equals(todayKey())?"Today":niceDateFor(date));}); row.addView(yes);
        Button no=action(s==2?"NO ✕":"NO"); no.setOnClickListener(v->{setStatus(t,date,2); showDay(date,date.equals(todayKey())?"Today":niceDateFor(date));}); row.addView(no);
        Button fav=action(t.fav?"★":"☆"); fav.setOnClickListener(v->{t.fav=!t.fav;save();showDay(date,date.equals(todayKey())?"Today":niceDateFor(date));}); row.addView(fav);
        Button edit=action("Edit"); edit.setOnClickListener(v->editTask(ix)); row.addView(edit);
        card.addView(row);
        String meta=t.category+" • "+t.priority+" • "+t.repeat;
        if(!t.note.isEmpty()) meta+="\n"+t.note;
        card.addView(text(meta,13));
        content.addView(card);
    }

    void showCalendar(){
        clear("Calendar");
        int year=monthCursor.get(Calendar.YEAR), month=monthCursor.get(Calendar.MONTH);
        content.addView(text(new SimpleDateFormat("MMMM yyyy",Locale.US).format(monthCursor.getTime()),21));
        LinearLayout controls=new LinearLayout(this);
        Button prev=action("‹ Prev"); Button next=action("Next ›"); Button today=action("Today");
        prev.setOnClickListener(v->{monthCursor.add(Calendar.MONTH,-1);showCalendar();});
        next.setOnClickListener(v->{monthCursor.add(Calendar.MONTH,1);showCalendar();});
        today.setOnClickListener(v->{monthCursor=Calendar.getInstance();showCalendar();});
        controls.addView(prev,new LinearLayout.LayoutParams(0,58,1)); controls.addView(today,new LinearLayout.LayoutParams(0,58,1)); controls.addView(next,new LinearLayout.LayoutParams(0,58,1));
        content.addView(controls);

        GridLayout grid=new GridLayout(this); grid.setColumnCount(7); grid.setUseDefaultMargins(true);
        String[] names={"Mon","Tue","Wed","Thu","Fri","Sat","Sun"};
        for(String n:names){ TextView h=text(n,12); h.setGravity(Gravity.CENTER); grid.addView(h,cellParams()); }
        Calendar first=new GregorianCalendar(year,month,1); int dow=first.get(Calendar.DAY_OF_WEEK); int mondayIndex=(dow+5)%7;
        for(int i=0;i<mondayIndex;i++) grid.addView(text("",12),cellParams());
        int days=first.getActualMaximum(Calendar.DAY_OF_MONTH);
        for(int d=1;d<=days;d++){
            String key=keyFor(year,month,d); int p=dayPercent(key);
            Button b=action(d+"\n"+p+"%"); b.setTextSize(12);
            if(key.equals(todayKey())) b.setTypeface(null,1);
            b.setOnClickListener(v->showDay(key,niceDateFor(key)));
            grid.addView(b,cellParams());
        }
        content.addView(grid);
        content.addView(text("\nMonthly completion",19));
        content.addView(new LineChartView(this,year,month));
        content.addView(text("Tap any date to record YES/NO for each task.",14));
    }

    GridLayout.LayoutParams cellParams(){ GridLayout.LayoutParams p=new GridLayout.LayoutParams(); p.width=0;p.height=72;p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);p.setMargins(2,2,2,2);return p; }

    void showStats(){
        clear("Statistics");
        int year=monthCursor.get(Calendar.YEAR), month=monthCursor.get(Calendar.MONTH);
        content.addView(text("Year overview: "+year,21));
        content.addView(new YearChartView(this,year));
        content.addView(text("\nMonth: "+new SimpleDateFormat("MMMM yyyy",Locale.US).format(monthCursor.getTime()),20));
        int p=monthCompleted(year,month); content.addView(text("Completion: "+p+"%",18));
        int yes=0,no=0,total=0;
        Calendar c=new GregorianCalendar(year,month,1); int days=c.getActualMaximum(Calendar.DAY_OF_MONTH);
        for(int d=1;d<=days;d++){String k=keyFor(year,month,d); total+=dayTotal(k);yes+=dayDone(k);no+=dayNo(k);}
        content.addView(text("YES: "+yes+"    NO: "+no+"    Pending: "+Math.max(0,total-yes-no),16));
        content.addView(text("Current streak: "+currentStreak()+" days",16));
        content.addView(text("Best streak: "+bestStreak()+" days",16));
        content.addView(text("\nTask performance",19));
        for(Task t:tasks){
            int count=0, ok=0;
            for(int d=1;d<=days;d++){String k=keyFor(year,month,d);if(isExpected(t,k)){count++;if(t.status(k)==1)ok++;}}
            content.addView(text(t.name+"  •  "+(count==0?0:ok*100/count)+"%  ("+ok+"/"+count+")",15));
        }
        Button prev=action("‹ Previous month"); Button next=action("Next month ›");
        prev.setOnClickListener(v->{monthCursor.add(Calendar.MONTH,-1);showStats();});
        next.setOnClickListener(v->{monthCursor.add(Calendar.MONTH,1);showStats();});
        content.addView(prev);content.addView(next);
    }

    int currentStreak(){
        Calendar c=Calendar.getInstance(); int streak=0;
        while(true){String k=dayKey.format(c.getTime());if(dayTotal(k)>0 && dayDone(k)==dayTotal(k)){streak++;c.add(Calendar.DAY_OF_MONTH,-1);}else break;if(streak>366)break;}
        return streak;
    }
    int bestStreak(){
        Calendar c=Calendar.getInstance();c.add(Calendar.DAY_OF_MONTH,-365);int best=0,cur=0;
        for(int i=0;i<366;i++){String k=dayKey.format(c.getTime());if(dayTotal(k)>0&&dayDone(k)==dayTotal(k)){cur++;best=Math.max(best,cur);}else cur=0;c.add(Calendar.DAY_OF_MONTH,1);}return best;
    }

    void showTasks(){
        clear("All Tasks"); updateSummaryFor(todayKey());
        Button add=action("+ ADD TASK"); add.setOnClickListener(v->editTask(-1)); content.addView(add);
        for(int i=0;i<tasks.size();i++) addTaskCard(i,todayKey());
        if(tasks.isEmpty()) content.addView(text("No tasks yet.",17));
    }

    void showMore(){
        clear("More"); updateSummaryFor(todayKey());
        content.addView(text("Data & settings",20));
        Button export=action("Export backup"); export.setOnClickListener(v->exportBackup()); content.addView(export);
        Button imp=action("Import backup"); imp.setOnClickListener(v->importBackup()); content.addView(imp);
        Button about=action("About V4"); about.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Task Tracker V4").setMessage("Daily YES/NO history, calendar, monthly graphs, yearly statistics, streaks and persistent local storage.").setPositiveButton("OK",null).show()); content.addView(about);
        content.addView(text("\nYour task history is stored locally on this phone. Use Export backup before uninstalling or changing versions.",14));
    }

    void editTask(int ix){
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);
        EditText name=new EditText(this);name.setHint("Task name");
        EditText category=new EditText(this);category.setHint("Category");
        EditText note=new EditText(this);note.setHint("Notes (optional)");
        Spinner priority=new Spinner(this);String[] ps={"High","Medium","Low"};priority.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,ps));
        Spinner repeat=new Spinner(this);String[] rs={"Once","Daily","Weekly","Monthly"};repeat.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,rs));
        form.addView(name);form.addView(category);form.addView(priority);form.addView(repeat);form.addView(note);
        if(ix>=0){Task t=tasks.get(ix);name.setText(t.name);category.setText(t.category);note.setText(t.note);for(int j=0;j<ps.length;j++)if(ps[j].equals(t.priority))priority.setSelection(j);for(int j=0;j<rs.length;j++)if(rs[j].equals(t.repeat))repeat.setSelection(j);}
        AlertDialog.Builder builder=new AlertDialog.Builder(this).setTitle(ix<0?"Add task":"Edit task").setView(form).setPositiveButton("Save",(d,w)->{
            String n=name.getText().toString().trim();if(n.isEmpty())return;String c=category.getText().toString().trim();if(c.isEmpty())c="General";
            if(ix<0)tasks.add(new Task(UUID.randomUUID().toString(),n,c,priority.getSelectedItem().toString(),repeat.getSelectedItem().toString(),note.getText().toString().trim()));
            else{Task t=tasks.get(ix);t.name=n;t.category=c;t.priority=priority.getSelectedItem().toString();t.repeat=repeat.getSelectedItem().toString();t.note=note.getText().toString().trim();}
            save();showToday();
        }).setNegativeButton("Cancel",null);
        if(ix>=0)builder.setNeutralButton("Delete",(d,w)->{tasks.remove(ix);save();showToday();});
        builder.show();
    }

    String keyFor(int year,int month,int day){ Calendar c=new GregorianCalendar(year,month,day);return dayKey.format(c.getTime()); }

    String clean(String s){return s.replace("\\","/").replace("|","/").replace("\n"," ").replace(";",",");}

    void save(){
        StringBuilder out=new StringBuilder();
        for(Task t:tasks){
            StringBuilder h=new StringBuilder();for(Map.Entry<String,Integer> e:t.history.entrySet()){if(h.length()>0)h.append(",");h.append(e.getKey()).append("=").append(e.getValue());}
            out.append(clean(t.id)).append("|").append(clean(t.name)).append("|").append(clean(t.category)).append("|").append(clean(t.priority)).append("|").append(clean(t.repeat)).append("|").append(clean(t.note)).append("|").append(t.fav?"1":"0").append("|").append(h).append("\n");
        }
        sp.edit().putString("data",out.toString()).apply();
    }

    void load(){
        String data=sp.getString("data","");
        if(!data.isEmpty()){parseV4(data);return;}
        SharedPreferences old=getSharedPreferences(OLD_PREF_V3,MODE_PRIVATE);String oldData=old.getString("data","");
        if(!oldData.isEmpty()){parseOldV3(oldData);save();return;}
        SharedPreferences v2=getSharedPreferences(OLD_PREF_V2,MODE_PRIVATE);String d2=v2.getString("data","");
        if(!d2.isEmpty()){parseOldV2(d2);save();return;}
        SharedPreferences v1=getSharedPreferences(OLD_PREF_V1,MODE_PRIVATE);String d1=v1.getString("data","");
        if(!d1.isEmpty()){parseOldV1(d1);save();}
    }

    void parseV4(String data){
        for(String line:data.split("\n")){String[] p=line.split("\\|",-1);if(p.length>=8){Task t=new Task(p[0],p[1],p[2],p[3],p[4],p[5]);t.fav=p[6].equals("1");if(!p[7].isEmpty())for(String e:p[7].split(",")){String[] q=e.split("=",-1);if(q.length==2)try{t.history.put(q[0],Integer.parseInt(q[1]));}catch(Exception ignored){}}tasks.add(t);}}
    }
    void parseOldV3(String data){
        for(String line:data.split("\n")){String[] p=line.split("\\|",-1);if(p.length>=8){Task t=new Task(p[0],p[1],p[2],p[3],p[4],p[5]);t.fav=p[7].equals("1");t.setStatus(todayKey(),p[6].equals("1")?1:0);tasks.add(t);}}
    }
    void parseOldV2(String data){
        for(String line:data.split("\n")){String[] p=line.split("\\|",-1);if(p.length>=6){Task t=new Task(UUID.randomUUID().toString(),p[0],p[1].isEmpty()?"General":p[1],"Medium",p[2].isEmpty()?"Once":p[2],p[3]);t.setStatus(todayKey(),p[4].equals("1")?1:0);t.fav=p[5].equals("1");tasks.add(t);}}
    }
    void parseOldV1(String data){
        for(String line:data.split("\n")){String[] p=line.split("\\|",-1);if(p.length>=3){Task t=new Task(UUID.randomUUID().toString(),p[0],"General","Medium","Once","");t.setStatus(todayKey(),p[1].equals("1")?1:0);t.fav=p[2].equals("1");tasks.add(t);}}
    }

    void exportBackup(){
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/plain");i.putExtra(Intent.EXTRA_TITLE,"TaskTracker_V4_Backup.txt");startActivityForResult(i,77);
    }
    void importBackup(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("text/plain");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,78);
    }
    protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data);
        if(res!=RESULT_OK||data==null)return;
        try{
            if(req==77){
                try(OutputStream out=getContentResolver().openOutputStream(data.getData())){out.write(sp.getString("data","").getBytes("UTF-8"));}
                Toast.makeText(this,"Backup exported",Toast.LENGTH_SHORT).show();
            }else if(req==78){
                StringBuilder sb=new StringBuilder();
                try(InputStream in=getContentResolver().openInputStream(data.getData());BufferedReader br=new BufferedReader(new InputStreamReader(in,"UTF-8"))){String line;while((line=br.readLine())!=null){sb.append(line).append('\n');}}
                sp.edit().putString("data",sb.toString()).apply();tasks.clear();load();showToday();Toast.makeText(this,"Backup restored",Toast.LENGTH_SHORT).show();
            }
        }catch(Exception e){Toast.makeText(this,"Backup operation failed",Toast.LENGTH_SHORT).show();}
    }

    static class ProgressView extends View{
        Paint p=new Paint(1);int percent;ProgressView(Context c,int x){super(c);percent=x;setMinimumHeight(55);}
        protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth()-30; p.setColor(Color.LTGRAY);c.drawRoundRect(15,15,w,40,15,15,p);p.setColor(PURPLE);c.drawRoundRect(15,15,15+w*percent/100f,40,15,15,p);p.setColor(Color.DKGRAY);p.setTextSize(14);c.drawText(percent+"%",18,35,p);}
    }

    class LineChartView extends View{
        Paint p=new Paint(1);int year,month;LineChartView(Context c,int y,int m){super(c);year=y;month=m;setMinimumHeight(260);}
        protected void onDraw(Canvas c){super.onDraw(c);int days=new GregorianCalendar(year,month,1).getActualMaximum(Calendar.DAY_OF_MONTH);float left=42,top=20,right=getWidth()-18,bottom=getHeight()-35; p.setColor(Color.GRAY);p.setStrokeWidth(2);c.drawLine(left,top,left,bottom,p);c.drawLine(left,bottom,right,bottom,p);p.setTextSize(10);for(int i=0;i<=4;i++){float y=bottom-(bottom-top)*i/4f;p.setColor(Color.LTGRAY);c.drawLine(left,y,right,y,p);p.setColor(Color.GRAY);c.drawText((i*25)+"%",4,y+4,p);}p.setColor(PURPLE);p.setStrokeWidth(4);float prevX=left,prevY=bottom;for(int d=1;d<=days;d++){int v=dayPercent(keyFor(year,month,d));float x=left+(right-left)*(d-1)/(float)Math.max(1,days-1);float y=bottom-(bottom-top)*v/100f;if(d>1)c.drawLine(prevX,prevY,x,y,p);c.drawCircle(x,y,3,p);prevX=x;prevY=y;}p.setColor(Color.GRAY);p.setTextSize(10);for(int d=1;d<=days;d+=5){float x=left+(right-left)*(d-1)/(float)Math.max(1,days-1);c.drawText(String.valueOf(d),x-4,bottom+18,p);}}
    }

    class YearChartView extends View{
        Paint p=new Paint(1);int year;YearChartView(Context c,int y){super(c);year=y;setMinimumHeight(260);}
        protected void onDraw(Canvas c){super.onDraw(c);float left=35,top=20,right=getWidth()-15,bottom=getHeight()-35;float bw=(right-left)/12f-6;p.setColor(Color.GRAY);p.setStrokeWidth(2);c.drawLine(left,bottom,right,bottom,p);for(int m=0;m<12;m++){int v=monthCompleted(year,m);float x=left+m*(right-left)/12f+3;float h=(bottom-top)*v/100f;p.setColor(PURPLE);c.drawRect(x,bottom-h,x+bw,bottom,p);p.setColor(Color.GRAY);p.setTextSize(9);String label=new SimpleDateFormat("MMM",Locale.US).format(new GregorianCalendar(year,m,1).getTime());c.drawText(label,x,bottom+15,p);if(v>0)c.drawText(v+"",x,bottom-h-4,p);}}
    }
}

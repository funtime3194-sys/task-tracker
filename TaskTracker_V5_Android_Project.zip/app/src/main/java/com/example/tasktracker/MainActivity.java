package com.example.tasktracker;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    static final String PREF="task_tracker_v4";
    static final String OLD_PREF_V3="task_tracker_v3";
    static final String OLD_PREF_V2="v2";
    static final String OLD_PREF_V1="tasks";
    static final int PURPLE=Color.rgb(79,70,229);
    LinearLayout content; TextView title,summary;
    ArrayList<Task> tasks=new ArrayList<>(); SharedPreferences sp;
    Calendar monthCursor=Calendar.getInstance();
    final SimpleDateFormat dayKey=new SimpleDateFormat("yyyy-MM-dd",Locale.US);
    final SimpleDateFormat niceDate=new SimpleDateFormat("EEE, dd MMM yyyy",Locale.US);

    static class Task {
        String id,name,category,priority,repeat,note; boolean fav;
        HashMap<String,Integer> history=new HashMap<>();
        Task(String id,String name,String category,String priority,String repeat,String note){this.id=id;this.name=name;this.category=category;this.priority=priority;this.repeat=repeat;this.note=note;}
        int status(String d){Integer v=history.get(d);return v==null?0:v;}
        void setStatus(String d,int s){if(s==0)history.remove(d);else history.put(d,s);}
    }

    public void onCreate(Bundle b){super.onCreate(b);sp=getSharedPreferences(PREF,MODE_PRIVATE);load();buildShell();showMonth();}
    String todayKey(){return dayKey.format(new Date());}
    TextView text(String s,float size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.rgb(25,25,35));t.setPadding(10,8,10,8);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(11);return b;}

    void buildShell(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(8,8,8,4);
        title=text("Task Tracker V5",26);title.setTypeface(null,1);root.addView(title);
        summary=text("",14);root.addView(summary);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this);nav.setBackgroundColor(Color.rgb(245,245,248));
        String[] ns={"Today","Month","Stats","Tasks","More"};
        for(String n:ns){Button b=btn(n);b.setOnClickListener(v->{if(n.equals("Today"))showDay(todayKey(),"Today");else if(n.equals("Month"))showMonth();else if(n.equals("Stats"))showStats();else if(n.equals("Tasks"))showTasks();else showMore();});nav.addView(b,new LinearLayout.LayoutParams(0,60,1));}
        root.addView(nav);setContentView(root);
    }
    void clear(String h){title.setText(h);content.removeAllViews();}
    String keyFor(int y,int m,int d){Calendar c=new GregorianCalendar(y,m,d);return dayKey.format(c.getTime());}
    String nice(String k){try{return niceDate.format(dayKey.parse(k));}catch(Exception e){return k;}}
    boolean expected(Task t,String k){if(t.repeat.equals("Daily")||t.repeat.equals("Monthly"))return true;if(t.repeat.equals("Weekly"))return true;return t.history.containsKey(k)||k.equals(todayKey());}
    int total(String k){int n=0;for(Task t:tasks)if(expected(t,k))n++;return n;}
    int yes(String k){int n=0;for(Task t:tasks)if(expected(t,k)&&t.status(k)==1)n++;return n;}
    int no(String k){int n=0;for(Task t:tasks)if(expected(t,k)&&t.status(k)==2)n++;return n;}
    int pct(String k){int n=total(k);return n==0?0:yes(k)*100/n;}
    void updateSummary(String k){int n=total(k),y=yes(k),no=no(k);summary.setText(nice(k)+"  •  "+y+" / "+n+" completed  •  "+pct(k)+"%  •  "+no+" no");}
    void setStatus(Task t,String d,int s){t.setStatus(d,s);save();}

    void showDay(String date,String h){selectedDate=date;clear(h);updateSummary(date);Button back=btn("← Monthly view");back.setOnClickListener(v->showMonth());content.addView(back);Button add=btn("+ ADD TASK");add.setOnClickListener(v->editTask(-1));content.addView(add);for(int i=0;i<tasks.size();i++)dayCard(i,date);content.addView(text("Daily completion: "+yes(date)+" / "+total(date)+" = "+pct(date)+"%",19));content.addView(new SingleDayBar(this,pct(date)));}
    String selectedDate=todayKey();
    void dayCard(int i,String d){Task t=tasks.get(i);LinearLayout row=new LinearLayout(this);row.setPadding(2,5,2,5);TextView n=text(t.name,16);n.setTypeface(null,1);row.addView(n,new LinearLayout.LayoutParams(0,-2,1));Button y=btn(t.status(d)==1?"YES ✓":"YES");Button no=btn(t.status(d)==2?"NO ✕":"NO");Button clear=btn("—");y.setOnClickListener(v->{setStatus(t,d,1);showDay(d,nice(d));});no.setOnClickListener(v->{setStatus(t,d,2);showDay(d,nice(d));});clear.setOnClickListener(v->{setStatus(t,d,0);showDay(d,nice(d));});row.addView(y);row.addView(no);row.addView(clear);content.addView(row);content.addView(text(t.category+" • "+t.priority+" • "+t.repeat,12));}

    void showMonth(){
        int y=monthCursor.get(Calendar.YEAR),m=monthCursor.get(Calendar.MONTH);clear("Monthly Tracker");
        LinearLayout ctl=new LinearLayout(this);Button prev=btn("‹");Button cur=btn(new SimpleDateFormat("MMMM yyyy",Locale.US).format(monthCursor.getTime()));Button next=btn("›");
        prev.setOnClickListener(v->{monthCursor.add(Calendar.MONTH,-1);showMonth();});next.setOnClickListener(v->{monthCursor.add(Calendar.MONTH,1);showMonth();});cur.setOnClickListener(v->{monthCursor=Calendar.getInstance();showMonth();});ctl.addView(prev,new LinearLayout.LayoutParams(70,58));ctl.addView(cur,new LinearLayout.LayoutParams(0,58,1));ctl.addView(next,new LinearLayout.LayoutParams(70,58));content.addView(ctl);
        int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH);
        content.addView(text("Tap any ✓ / ✕ / — cell to change a task result. Tap a day header to see that day's full result.",13));
        HorizontalScrollView hsv=new HorizontalScrollView(this);LinearLayout matrix=new LinearLayout(this);matrix.setOrientation(LinearLayout.VERTICAL);
        LinearLayout header=new LinearLayout(this);header.addView(cell("TASK",150,true));
        for(int d=1;d<=days;d++){final String k=keyFor(y,m,d);Button b=btn(String.valueOf(d));b.setTextSize(11);b.setOnClickListener(v->showDay(k,nice(k)));header.addView(b,cellParams(58));}matrix.addView(header);
        if(tasks.isEmpty())matrix.addView(text("No tasks. Add one from Tasks.",16));
        for(Task t:tasks){LinearLayout r=new LinearLayout(this);TextView name=cell(t.name,150,true);name.setOnClickListener(v->showTaskMonth(t));r.addView(name);for(int d=1;d<=days;d++){String k=keyFor(y,m,d);Button b=btn(mark(t.status(k)));b.setTextSize(12);b.setOnClickListener(v->chooseStatus(t,k));r.addView(b,cellParams(58));}matrix.addView(r);}
        hsv.addView(matrix);content.addView(hsv,new LinearLayout.LayoutParams(-1,-2));
        content.addView(text("Daily completion graph",18));content.addView(new MonthChart(this,y,m));
        int sum=0,count=0;for(int d=1;d<=days;d++){String k=keyFor(y,m,d);if(total(k)>0){sum+=pct(k);count++;}}content.addView(text("Month average: "+(count==0?0:sum/count)+"%",17));
    }
    TextView cell(String s,int w,boolean bold){TextView t=text(s,12);t.setGravity(Gravity.CENTER_VERTICAL);if(bold)t.setTypeface(null,1);t.setBackgroundColor(Color.rgb(238,238,242));t.setMinWidth(w);t.setMaxWidth(w);return t;}
    LinearLayout.LayoutParams cellParams(int w){return new LinearLayout.LayoutParams(w,58);}
    String mark(int s){return s==1?"✓":s==2?"✕":"—";}
    void chooseStatus(Task t,String k){new AlertDialog.Builder(this).setTitle(t.name+" • "+nice(k)).setItems(new String[]{"✓ YES / Completed","✕ NO / Not completed","— Pending / Clear"},(d,w)->{setStatus(t,k,w==0?1:w==1?2:0);showMonth();}).show();}
    void showTaskMonth(Task t){int y=monthCursor.get(Calendar.YEAR),m=monthCursor.get(Calendar.MONTH);clear(t.name);content.addView(text(new SimpleDateFormat("MMMM yyyy",Locale.US).format(monthCursor.getTime()),18));int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH);int sum=0,c=0;for(int d=1;d<=days;d++){String k=keyFor(y,m,d);if(expected(t,k)){if(t.status(k)==1)sum++;c++;content.addView(text(d+"  "+mark(t.status(k))+"   "+pct(k)+"% day total",15));}}content.addView(text("Task monthly completion: "+(c==0?0:sum*100/c)+"%",18));content.addView(new MonthChart(this,y,m));}

    void showStats(){clear("Reports");int y=monthCursor.get(Calendar.YEAR),m=monthCursor.get(Calendar.MONTH);content.addView(text("Daily completion — "+new SimpleDateFormat("MMMM yyyy",Locale.US).format(monthCursor.getTime()),19));content.addView(new MonthChart(this,y,m));int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH);int sum=0,c=0;for(int d=1;d<=days;d++){String k=keyFor(y,m,d);if(total(k)>0){sum+=pct(k);c++;}}content.addView(text("Monthly average: "+(c==0?0:sum/c)+"%",18));content.addView(text("Yearly monthly averages — "+y,19));content.addView(new YearChart(this,y));}

    void showTasks(){clear("Tasks");Button add=btn("+ ADD TASK");add.setOnClickListener(v->editTask(-1));content.addView(add);for(int i=0;i<tasks.size();i++){final int ix=i;LinearLayout r=new LinearLayout(this);TextView n=text(tasks.get(i).name,17);n.setTypeface(null,1);r.addView(n,new LinearLayout.LayoutParams(0,-2,1));Button e=btn("EDIT");e.setOnClickListener(v->editTask(ix));r.addView(e);content.addView(r);}}
    void showMore(){clear("More");Button ex=btn("Export backup");ex.setOnClickListener(v->exportBackup());content.addView(ex);Button im=btn("Import backup");im.setOnClickListener(v->importBackup());content.addView(im);content.addView(text("V5 stores task results by task and calendar date. Previous days are not replaced when the date changes.",14));}

    void editTask(int ix){LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);EditText n=new EditText(this);n.setHint("Task name");EditText c=new EditText(this);c.setHint("Category");EditText note=new EditText(this);note.setHint("Notes");Spinner p=new Spinner(this);p.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"High","Medium","Low"}));Spinner r=new Spinner(this);r.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Once","Daily","Weekly","Monthly"}));f.addView(n);f.addView(c);f.addView(p);f.addView(r);f.addView(note);if(ix>=0){Task t=tasks.get(ix);n.setText(t.name);c.setText(t.category);note.setText(t.note);String[] ps={"High","Medium","Low"},rs={"Once","Daily","Weekly","Monthly"};for(int j=0;j<3;j++)if(ps[j].equals(t.priority))p.setSelection(j);for(int j=0;j<4;j++)if(rs[j].equals(t.repeat))r.setSelection(j);}AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle(ix<0?"Add task":"Edit task").setView(f).setPositiveButton("SAVE",(d,w)->{String nn=n.getText().toString().trim();if(nn.isEmpty())return;String cc=c.getText().toString().trim();if(cc.isEmpty())cc="General";if(ix<0)tasks.add(new Task(UUID.randomUUID().toString(),nn,cc,p.getSelectedItem().toString(),r.getSelectedItem().toString(),note.getText().toString().trim()));else{Task t=tasks.get(ix);t.name=nn;t.category=cc;t.priority=p.getSelectedItem().toString();t.repeat=r.getSelectedItem().toString();t.note=note.getText().toString().trim();}save();showMonth();}).setNegativeButton("CANCEL",null);if(ix>=0)b.setNeutralButton("DELETE",(d,w)->{tasks.remove(ix);save();showMonth();});b.show();}

    void save(){StringBuilder o=new StringBuilder();for(Task t:tasks){StringBuilder h=new StringBuilder();for(Map.Entry<String,Integer>e:t.history.entrySet()){if(h.length()>0)h.append(",");h.append(e.getKey()).append("=").append(e.getValue());}o.append(clean(t.id)).append("|").append(clean(t.name)).append("|").append(clean(t.category)).append("|").append(clean(t.priority)).append("|").append(clean(t.repeat)).append("|").append(clean(t.note)).append("|").append(t.fav?"1":"0").append("|").append(h).append("\n");}sp.edit().putString("data",o.toString()).apply();}
    String clean(String s){return s.replace("\\","/").replace("|","/").replace("\n"," ").replace(";",",");}
    void load(){String data=sp.getString("data","");if(!data.isEmpty()){parse(data);return;}SharedPreferences old=getSharedPreferences(OLD_PREF_V3,MODE_PRIVATE);String od=old.getString("data","");if(!od.isEmpty()){parseOld(od);save();return;}SharedPreferences v2=getSharedPreferences(OLD_PREF_V2,MODE_PRIVATE);od=v2.getString("data","");if(!od.isEmpty()){parseOld(od);save();return;}SharedPreferences v1=getSharedPreferences(OLD_PREF_V1,MODE_PRIVATE);od=v1.getString("data","");if(!od.isEmpty()){parseOld(od);save();}}
    void parse(String data){for(String line:data.split("\n")){String[]p=line.split("\\|",-1);if(p.length>=8){Task t=new Task(p[0],p[1],p[2],p[3],p[4],p[5]);t.fav=p[6].equals("1");if(!p[7].isEmpty())for(String e:p[7].split(",")){String[]q=e.split("=",-1);if(q.length==2)try{t.history.put(q[0],Integer.parseInt(q[1]));}catch(Exception ignored){}}tasks.add(t);}}}
    void parseOld(String data){for(String line:data.split("\n")){String[]p=line.split("\\|",-1);if(p.length>=8){Task t=new Task(p[0],p[1],p[2],p[3],p[4],p[5]);t.fav=p[7].equals("1");t.setStatus(todayKey(),p[6].equals("1")?1:0);tasks.add(t);}}}
    void exportBackup(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/plain");i.putExtra(Intent.EXTRA_TITLE,"TaskTracker_V5_Backup.txt");startActivityForResult(i,77);}
    void importBackup(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("text/plain");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,78);}
    protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;try{if(req==77){OutputStream out=getContentResolver().openOutputStream(data.getData());out.write(sp.getString("data","").getBytes("UTF-8"));out.close();Toast.makeText(this,"Backup exported",Toast.LENGTH_SHORT).show();}else if(req==78){BufferedReader br=new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(data.getData()),"UTF-8"));StringBuilder sb=new StringBuilder();String l;while((l=br.readLine())!=null)sb.append(l).append('\n');br.close();sp.edit().putString("data",sb.toString()).apply();tasks.clear();load();showMonth();Toast.makeText(this,"Backup restored",Toast.LENGTH_SHORT).show();}}catch(Exception e){Toast.makeText(this,"Backup operation failed",Toast.LENGTH_SHORT).show();}}

    class SingleDayBar extends View{Paint p=new Paint(1);int v;SingleDayBar(Context c,int x){super(c);v=x;setMinimumHeight(50);}protected void onDraw(Canvas c){float l=15,r=getWidth()-15;p.setColor(Color.LTGRAY);c.drawRoundRect(l,12,r,36,12,12,p);p.setColor(PURPLE);c.drawRoundRect(l,12,l+(r-l)*v/100f,36,12,12,p);p.setColor(Color.DKGRAY);p.setTextSize(13);c.drawText(v+"%",20,30,p);}}
    class MonthChart extends View{Paint p=new Paint(1);int y,m;MonthChart(Context c,int yy,int mm){super(c);y=yy;m=mm;setMinimumHeight(250);}protected void onDraw(Canvas c){float l=40,t=18,r=getWidth()-15,b=getHeight()-35;p.setStrokeWidth(2);p.setColor(Color.GRAY);c.drawLine(l,t,l,b,p);c.drawLine(l,b,r,b,p);p.setTextSize(9);for(int q=0;q<=4;q++){float yy=b-(b-t)*q/4;p.setColor(Color.LTGRAY);c.drawLine(l,yy,r,yy,p);p.setColor(Color.GRAY);c.drawText((q*25)+"%",2,yy+3,p);}int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH);float px=0,py=0;p.setColor(PURPLE);p.setStrokeWidth(4);for(int d=1;d<=days;d++){float x=l+(r-l)*(d-1)/(float)Math.max(1,days-1);float yy=b-(b-t)*pct(keyFor(y,m,d))/100f;if(d>1)c.drawLine(px,py,x,yy,p);c.drawCircle(x,yy,3,p);px=x;py=yy;}p.setColor(Color.GRAY);p.setTextSize(9);for(int d=1;d<=days;d+=5){float x=l+(r-l)*(d-1)/(float)Math.max(1,days-1);c.drawText(""+d,x-3,b+17,p);}}}
    class YearChart extends View{Paint p=new Paint(1);int y;YearChart(Context c,int yy){super(c);y=yy;setMinimumHeight(220);}protected void onDraw(Canvas c){float l=35,t=15,r=getWidth()-10,b=getHeight()-30;float bw=(r-l)/12f-5;p.setColor(Color.GRAY);c.drawLine(l,b,r,b,p);for(int m=0;m<12;m++){int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH);int s=0,n=0;for(int d=1;d<=days;d++){String k=keyFor(y,m,d);if(total(k)>0){s+=pct(k);n++;}}int v=n==0?0:s/n;float x=l+m*(r-l)/12f+2;float h=(b-t)*v/100f;p.setColor(PURPLE);c.drawRect(x,b-h,x+bw,b,p);p.setColor(Color.GRAY);p.setTextSize(8);c.drawText(new SimpleDateFormat("MMM",Locale.US).format(new GregorianCalendar(y,m,1).getTime()),x,b+14,p);if(v>0)c.drawText(""+v,x,b-h-3,p);}}}
}

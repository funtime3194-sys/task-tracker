package com.example.tasktracker;

import android.app.*;
import android.content.*;
import android.os.*;

public class ReminderReceiver extends BroadcastReceiver {
  public void onReceive(Context context, Intent intent){
    String name=intent.getStringExtra("taskName"); if(name==null||name.isEmpty()) name="Task reminder";
    if(Build.VERSION.SDK_INT>=26){NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);NotificationChannel ch=new NotificationChannel("task_reminders","Task reminders",NotificationManager.IMPORTANCE_DEFAULT);nm.createNotificationChannel(ch);}
    PendingIntent open=PendingIntent.getActivity(context,0,new Intent(context,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,"task_reminders"):new Notification.Builder(context);
    b.setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("Task reminder").setContentText(name).setAutoCancel(true).setContentIntent(open);
    NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);nm.notify(Math.abs(name.hashCode()),b.build());
  }
}
